
/* eslint-disable no-restricted-globals */
/* global self, clients */

// Security Service Worker
// Forces HTTPS and caches core assets for offline capability

const CACHE_NAME = 'security-cache-v1';

self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(clients.claim());
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // 1. Force HTTPS for all non-local requests
  if (url.protocol === 'http:' && 
      !url.hostname.includes('localhost') && 
      !url.hostname.includes('127.0.0.1') &&
      !url.hostname.includes('::1')) {
    
    const httpsUrl = event.request.url.replace('http://', 'https://');
    event.respondWith(Response.redirect(httpsUrl, 301));
    return;
  }

  // 2. Default network behavior
  event.respondWith(fetch(event.request));
});
