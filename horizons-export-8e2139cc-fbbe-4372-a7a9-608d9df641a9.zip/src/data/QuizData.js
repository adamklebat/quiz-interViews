
const quizData = [
  // ==========================================
  // HTML SECTION (IDs 1-80)
  // Total: 80 Questions
  // ==========================================
  {
    id: 1,
    category: "HTML",
    question: "ما هو المعنى الكامل لـ HTML؟",
    options: [
      "Hyper Text Markup Language",
      "High Tech Modern Language",
      "Home Tool Markup Language",
      "Hyperlinks and Text Markup Language"
    ],
    correctAnswer: 0,
    explanation: "HTML هي اختصار لـ Hyper Text Markup Language، وهي اللغة القياسية لإنشاء صفحات الويب وتطبيقات الويب."
  },
  {
    id: 2,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء عنوان من المستوى الأول؟",
    options: ["<heading>", "<h1>", "<head>", "<header>"],
    correctAnswer: 1,
    explanation: "الوسم <h1> يُستخدم لتعريف العنوان الرئيسي والأكثر أهمية في الصفحة. العناوين تتدرج من <h1> إلى <h6>."
  },
  {
    id: 3,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء فقرة نصية؟",
    options: ["<paragraph>", "<text>", "<p>", "<pg>"],
    correctAnswer: 2,
    explanation: "الوسم <p> (اختصار لـ Paragraph) هو الوسم الصحيح لتعريف فقرة نصية في HTML."
  },
  {
    id: 4,
    category: "HTML",
    question: "كيف تُنشئ رابطاً في HTML؟",
    options: ["<link>", "<a>", "<href>", "<url>"],
    correctAnswer: 1,
    explanation: "يتم إنشاء الروابط باستخدام وسم المرساة <a> (Anchor)، مع استخدام السمة href لتحديد الوجهة."
  },
  {
    id: 5,
    category: "HTML",
    question: "أي صيغة صحيحة لإضافة صورة في HTML؟",
    options: [
      "<image src='photo.jpg'>",
      "<img src='photo.jpg'>",
      "<picture src='photo.jpg'>",
      "<photo src='photo.jpg'>"
    ],
    correctAnswer: 1,
    explanation: "الوسم <img> هو المستخدم لإدراج الصور، وهو وسم يغلق ذاتياً ولا يحتاج لوسم إغلاق، والسمة src تحدد مسار الصورة."
  },
  {
    id: 6,
    category: "HTML",
    question: "ما هو الوسم المستخدم لإنشاء قائمة غير مرتبة؟",
    options: ["<ol>", "<list>", "<ul>", "<ulist>"],
    correctAnswer: 2,
    explanation: "الوسم <ul> (Unordered List) يُستخدم لإنشاء قائمة نقطية غير مرتبة، بينما <ol> للقوائم المرتبة رقمياً."
  },
  {
    id: 7,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء قائمة مرتبة؟",
    options: ["<ul>", "<list>", "<ol>", "<order>"],
    correctAnswer: 2,
    explanation: "الوسم <ol> (Ordered List) يُستخدم لإنشاء قائمة مرتبة (مرقمة 1، 2، 3...)."
  },
  {
    id: 8,
    category: "HTML",
    question: "كيف تُنشئ عنصر قائمة داخل قائمة؟",
    options: ["<item>", "<list>", "<li>", "<element>"],
    correctAnswer: 2,
    explanation: "الوسم <li> (List Item) يُستخدم لتعريف كل عنصر داخل القوائم سواء كانت مرتبة <ol> أو غير مرتبة <ul>."
  },
  {
    id: 9,
    category: "HTML",
    question: "أي وسم يُستخدم لجعل النص غامقاً (Bold)؟",
    options: ["<b>", "<bold>", "<strong>", "كلا الخيارين <b> و <strong>"],
    correctAnswer: 3,
    explanation: "كلا الوسمين <b> و <strong> يجعلان النص غامقاً، لكن <strong> يضيف دلالة سيمانيكية بأن النص 'هام'."
  },
  {
    id: 10,
    category: "HTML",
    question: "كيف تُنشئ خطاً أفقياً في HTML؟",
    options: ["<line>", "<hr>", "<break>", "<horizontal>"],
    correctAnswer: 1,
    explanation: "الوسم <hr> (Horizontal Rule) يُستخدم لرسم خط أفقي فاصل بين المحتوى."
  },
  {
    id: 11,
    category: "HTML",
    question: "أي وسم يُستخدم لجعل النص مائلاً (Italic)؟",
    options: ["<italic>", "<i>", "<em>", "كلا الخيارين <i> و <em>"],
    correctAnswer: 3,
    explanation: "كلا الوسمين <i> و <em> يجعلان النص مائلاً، لكن <em> (Emphasis) يضيف تأكيداً دلالياً على النص."
  },
  {
    id: 12,
    category: "HTML",
    question: "ما هو الوسم المستخدم لإضافة تعليق في HTML؟",
    options: [
      "// تعليق",
      "<!-- تعليق -->",
      "/* تعليق */",
      "# تعليق"
    ],
    correctAnswer: 1,
    explanation: "تتم كتابة التعليقات في HTML بين العلامتين <!-- و -->، ولا تظهر هذه التعليقات في المتصفح."
  },
  {
    id: 13,
    category: "HTML",
    question: "أي وسم يُحدد عنوان المستند في نافذة المتصفح؟",
    options: ["<head>", "<title>", "<meta>", "<header>"],
    correctAnswer: 1,
    explanation: "الوسم <title> يوضع داخل <head> ويحدد العنوان الذي يظهر في شريط عنوان المتصفح أو في نتائج البحث."
  },
  {
    id: 14,
    category: "HTML",
    question: "أين يوضع وسم <title> في مستند HTML؟",
    options: [
      "في <body>",
      "في <head>",
      "في <footer>",
      "في أي مكان"
    ],
    correctAnswer: 1,
    explanation: "يجب وضع وسم <title> دائماً داخل قسم <head> في مستند HTML."
  },
  {
    id: 15,
    category: "HTML",
    question: "كيف تُنشئ جدولاً في HTML؟",
    options: ["<table>", "<tab>", "<grid>", "<tbl>"],
    correctAnswer: 0,
    explanation: "الوسم <table> هو الحاوية الرئيسية لإنشاء الجداول في HTML."
  },
  {
    id: 16,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء صف في الجدول؟",
    options: ["<row>", "<tr>", "<td>", "<line>"],
    correctAnswer: 1,
    explanation: "الوسم <tr> (Table Row) يُستخدم لتعريف صف جديد داخل الجدول."
  },
  {
    id: 17,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء خلية بيانات في الجدول؟",
    options: ["<cell>", "<data>", "<td>", "<tc>"],
    correctAnswer: 2,
    explanation: "الوسم <td> (Table Data) يُستخدم لتعريف خلية قياسية تحتوي على بيانات داخل صف الجدول."
  },
  {
    id: 18,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء خلية رأس الجدول؟",
    options: ["<thead>", "<header>", "<th>", "<head>"],
    correctAnswer: 2,
    explanation: "الوسم <th> (Table Header) يُستخدم لتعريف خلية رأسية في الجدول، وعادة ما يكون النص بداخلها غامقاً ومحاذياً للوسط."
  },
  {
    id: 19,
    category: "HTML",
    question: "كيف تُنشئ نموذجاً (Form) في HTML؟",
    options: ["<form>", "<input>", "<field>", "<formdata>"],
    correctAnswer: 0,
    explanation: "الوسم <form> يُستخدم لإنشاء نموذج HTML لجمع مدخلات المستخدم."
  },
  {
    id: 20,
    category: "HTML",
    question: "أي سمة تُحدد عنوان URL الذي سيتم إرسال بيانات النموذج إليه؟",
    options: ["method", "action", "submit", "target"],
    correctAnswer: 1,
    explanation: "السمة action تحدد الوجهة (URL) التي ستُرسل إليها بيانات النموذج عند النقر على زر الإرسال."
  },
  {
    id: 21,
    category: "HTML",
    question: "أي نوع من حقول الإدخال يُستخدم لإدخال كلمة المرور؟",
    options: [
      "type='text'",
      "type='password'",
      "type='secret'",
      "type='hidden'"
    ],
    correctAnswer: 1,
    explanation: "input type='password' يخفي الحروف المدخلة (يظهرها كنقاط أو نجوم) لأغراض الأمان."
  },
  {
    id: 22,
    category: "HTML",
    question: "كيف تُنشئ زر إرسال في النموذج؟",
    options: [
      "<button type='send'>",
      "<input type='submit'>",
      "<submit>",
      "<send>"
    ],
    correctAnswer: 1,
    explanation: "<input type='submit'> ينشئ زراً يقوم بإرسال بيانات النموذج إلى الخادم المحدد في action."
  },
  {
    id: 23,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء قائمة منسدلة؟",
    options: ["<list>", "<dropdown>", "<select>", "<option>"],
    correctAnswer: 2,
    explanation: "الوسم <select> يُستخدم لإنشاء قائمة منسدلة (Drop-down list)."
  },
  {
    id: 24,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء خيار داخل قائمة منسدلة؟",
    options: ["<item>", "<choice>", "<option>", "<select>"],
    correctAnswer: 2,
    explanation: "الوسم <option> يُستخدم لتعريف العناصر القابلة للاختيار داخل قائمة <select>."
  },
  {
    id: 25,
    category: "HTML",
    question: "كيف تُنشئ منطقة نص متعددة الأسطر؟",
    options: [
      "<input type='text'>",
      "<textbox>",
      "<textarea>",
      "<text>"
    ],
    correctAnswer: 2,
    explanation: "الوسم <textarea> يُستخدم لإنشاء حقل إدخال نصي يقبل عدة أسطر، بعكس input type='text' الذي يقبل سطراً واحداً."
  },
  {
    id: 26,
    category: "HTML",
    question: "أي سمة تجعل حقل الإدخال مطلوباً؟",
    options: ["mandatory", "required", "needed", "validate"],
    correctAnswer: 1,
    explanation: "السمة required تمنع إرسال النموذج إذا كان حقل الإدخال فارغاً."
  },
  {
    id: 27,
    category: "HTML",
    question: "كيف تُنشئ مربع اختيار (Checkbox)؟",
    options: [
      "<input type='check'>",
      "<checkbox>",
      "<input type='checkbox'>",
      "<check>"
    ],
    correctAnswer: 2,
    explanation: "<input type='checkbox'> ينشئ مربع اختيار يسمح للمستخدم بتحديد خيار واحد أو أكثر."
  },
  {
    id: 28,
    category: "HTML",
    question: "كيف تُنشئ زر اختيار دائري (Radio Button)؟",
    options: [
      "<input type='radio'>",
      "<radio>",
      "<input type='circle'>",
      "<button type='radio'>"
    ],
    correctAnswer: 0,
    explanation: "<input type='radio'> ينشئ زر اختيار يسمح للمستخدم باختيار قيمة واحدة فقط من مجموعة خيارات."
  },
  {
    id: 29,
    category: "HTML",
    question: "أي وسم يُستخدم لإضافة فيديو في HTML5؟",
    options: ["<movie>", "<media>", "<video>", "<film>"],
    correctAnswer: 2,
    explanation: "الوسم <video> هو الوسم القياسي في HTML5 لتضمين محتوى الفيديو."
  },
  {
    id: 30,
    category: "HTML",
    question: "أي وسم يُستخدم لإضافة ملف صوتي في HTML5؟",
    options: ["<sound>", "<music>", "<audio>", "<mp3>"],
    correctAnswer: 2,
    explanation: "الوسم <audio> هو الوسم القياسي في HTML5 لتضمين المحتوى الصوتي."
  },
  {
    id: 31,
    category: "HTML",
    question: "ما هو الوسم الصحيح لأكبر عنوان؟",
    options: ["<h6>", "<heading>", "<h1>", "<head>"],
    correctAnswer: 2,
    explanation: "<h1> يمثل العنوان الأكبر والأكثر أهمية، بينما <h6> يمثل العنوان الأصغر."
  },
  {
    id: 32,
    category: "HTML",
    question: "ما هو الوسم الصحيح لأصغر عنوان؟",
    options: ["<h1>", "<h7>", "<h6>", "<heading>"],
    correctAnswer: 2,
    explanation: "<h6> هو أصغر مستوى للعناوين في HTML (لا يوجد h7)."
  },
  {
    id: 33,
    category: "HTML",
    question: "كيف يمكن فتح رابط في نافذة جديدة؟",
    options: [
      "target='_blank'",
      "target='new'",
      "window='new'",
      "open='new'"
    ],
    correctAnswer: 0,
    explanation: "إضافة السمة target='_blank' إلى وسم الرابط <a> تجعل الرابط يفتح في علامة تبويب أو نافذة جديدة."
  },
  {
    id: 34,
    category: "HTML",
    question: "أي سمة تُستخدم لتحديد نص بديل للصورة؟",
    options: ["title", "alt", "text", "description"],
    correctAnswer: 1,
    explanation: "السمة alt توفر نصاً بديلاً يظهر إذا لم يتم تحميل الصورة، وهو مهم لسهولة الوصول (Accessibility)."
  },
  {
    id: 35,
    category: "HTML",
    question: "ما هو الامتداد الصحيح لملف HTML؟",
    options: [".txt", ".xml", ".html", ".htm", "كلا .html و .htm"],
    correctAnswer: 4,
    explanation: "كلا الامتدادين .html و .htm مقبولان وصحيحان لملفات HTML."
  },
  {
    id: 36,
    category: "HTML",
    question: "أي وسم يُعرّف قسم التنقل في الصفحة؟",
    options: ["<navigation>", "<nav>", "<menu>", "<links>"],
    correctAnswer: 1,
    explanation: "الوسم <nav> يُستخدم لتعريف قسم يحتوي على روابط التنقل الرئيسية في الموقع."
  },
  {
    id: 37,
    category: "HTML",
    question: "أي وسم يُعرّف رأس الصفحة أو القسم؟",
    options: ["<head>", "<top>", "<header>", "<section>"],
    correctAnswer: 2,
    explanation: "الوسم <header> يُستخدم لتعريف مقدمة أو رأس الصفحة أو القسم، وغالباً ما يحتوي على شعار وعناوين."
  },
  {
    id: 38,
    category: "HTML",
    question: "أي وسم يُعرّف تذييل الصفحة أو القسم؟",
    options: ["<bottom>", "<footer>", "<end>", "<foot>"],
    correctAnswer: 1,
    explanation: "الوسم <footer> يُستخدم لتعريف تذييل الصفحة أو القسم، ويحتوي عادة على حقوق النشر ومعلومات الاتصال."
  },
  {
    id: 39,
    category: "HTML",
    question: "أي وسم يُعرّف قسماً في المستند؟",
    options: ["<div>", "<section>", "<part>", "<segment>"],
    correctAnswer: 1,
    explanation: "الوسم <section> يُستخدم لتعريف قسم موضوعي في المستند، وعادة ما يكون له عنوان."
  },
  {
    id: 40,
    category: "HTML",
    question: "أي وسم يُعرّف مقالة مستقلة؟",
    options: ["<article>", "<post>", "<content>", "<text>"],
    correctAnswer: 0,
    explanation: "الوسم <article> يُستخدم لتعريف محتوى مستقل وقائم بذاته مثل مقال إخباري أو تدوينة."
  },
  {
    id: 41,
    category: "HTML",
    question: "أي وسم يُعرّف محتوى جانبياً؟",
    options: ["<sidebar>", "<aside>", "<side>", "<extra>"],
    correctAnswer: 1,
    explanation: "الوسم <aside> يُستخدم لتعريف محتوى مرتبط بشكل ثانوي بالمحتوى الرئيسي (مثل شريط جانبي)."
  },
  {
    id: 42,
    category: "HTML",
    question: "كيف تُضيف لوناً للخلفية في HTML باستخدام السمات؟",
    options: [
      "background='red'",
      "bgcolor='red'",
      "color='red'",
      "يُفضل استخدام CSS"
    ],
    correctAnswer: 3,
    explanation: "على الرغم من وجود سمات قديمة مثل bgcolor، إلا أن الطريقة الصحيحة والحديثة هي استخدام CSS (مثلاً: style='background-color: red')."
  },
  {
    id: 43,
    category: "HTML",
    question: "أي وسم يُستخدم لتعريف نص منسق مسبقاً؟",
    options: ["<format>", "<pre>", "<code>", "<text>"],
    correctAnswer: 1,
    explanation: "الوسم <pre> (Preformatted Text) يعرض النص تماماً كما هو مكتوب في ملف HTML، بما في ذلك المسافات والأسطر الجديدة."
  },
  {
    id: 45,
    category: "HTML",
    question: "كيف تُنشئ فاصل سطر في HTML؟",
    options: ["<break>", "<lb>", "<br>", "<newline>"],
    correctAnswer: 2,
    explanation: "الوسم <br> (Break) يُستخدم لإدراج فاصل سطر واحد (نزول لسطر جديد)."
  },
  {
    id: 46,
    category: "HTML",
    question: "أي سمة تُحدد اللغة في HTML؟",
    options: ["language", "lang", "locale", "translate"],
    correctAnswer: 1,
    explanation: "السمة lang في وسم <html> (مثل <html lang='ar'>) تحدد لغة محتوى الصفحة."
  },
  {
    id: 47,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء اقتباس قصير؟",
    options: ["<quote>", "<q>", "<citation>", "<blockquote>"],
    correctAnswer: 1,
    explanation: "الوسم <q> يُستخدم للاقتباسات القصيرة المضمنة في النص، وعادة ما يضيف المتصفح علامات تنصيص حوله."
  },
  {
    id: 48,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء اقتباس طويل (كتلة)؟",
    options: ["<quote>", "<q>", "blockquote", "<citation>"],
    correctAnswer: 2,
    explanation: "الوسم <blockquote> يُستخدم للاقتباسات الطويلة التي تشكل فقرة أو كتلة منفصلة."
  },
  {
    id: 49,
    category: "HTML",
    question: "أي وسم يُستخدم لتعريف نص مُختصر؟",
    options: ["<short>", "<abbr>", "<acronym>", "<abbreviation>"],
    correctAnswer: 1,
    explanation: "الوسم <abbr> يُستخدم لتعريف الاختصارات (مثل HTML, CSS)."
  },
  {
    id: 50,
    category: "HTML",
    question: "أي وسم يُستخدم لتعريف عنوان عمل (كتاب، فيلم، إلخ)؟",
    options: ["<title>", "<cite>", "<work>", "<name>"],
    correctAnswer: 1,
    explanation: "الوسم <cite> يُستخدم للإشارة إلى عنوان عمل إبداعي (مثل كتاب أو فيلم)."
  },
  {
    id: 51,
    category: "HTML",
    question: "كيف تُنشئ نصاً مشطوباً؟",
    options: ["<strike>", "<del>", "<s>", "جميع ما سبق"],
    correctAnswer: 3,
    explanation: "جميع الوسوم <del>, <s>, و <strike> (القديم) تُستخدم لشطب النص، لكن <del> يشير تحديداً لنص محذوف."
  },
  {
    id: 52,
    category: "HTML",
    question: "كيف تُنشئ نصاً مُسطّراً؟",
    options: ["<underline>", "<u>", "<line>", "<ul>"],
    correctAnswer: 1,
    explanation: "الوسم <u> يُستخدم لوضع خط تحت النص."
  },
  {
    id: 53,
    category: "HTML",
    question: "أي وسم يُستخدم لتعريف نص صغير؟",
    options: ["<tiny>", "<small>", "<mini>", "<sm>"],
    correctAnswer: 1,
    explanation: "الوسم <small> يجعل النص أصغر حجماً من النص الافتراضي."
  },
  {
    id: 54,
    category: "HTML",
    question: "أي وسم يُستخدم لتعريف نص مُميز (Highlighted)؟",
    options: ["<highlight>", "<mark>", "<hl>", "<em>"],
    correctAnswer: 1,
    explanation: "الوسم <mark> يُستخدم لتمييز النص (تظليله) بلون خلفية (أصفر عادةً)."
  },
  {
    id: 55,
    category: "HTML",
    question: "أي وسم يُستخدم لتعريف نص فوقي (Superscript)؟",
    options: ["<super>", "<sup>", "<high>", "<upper>"],
    correctAnswer: 1,
    explanation: "الوسم <sup> يرفع النص للأعلى ويصغره (مثل الأسس في الرياضيات x²)."
  },
  {
    id: 56,
    category: "HTML",
    question: "أي وسم يُستخدم لتعريف نص تحتي (Subscript)؟",
    options: ["<lower>", "<sub>", "<bottom>", "<down>"],
    correctAnswer: 1,
    explanation: "الوسم <sub> يخفض النص للأسفل ويصغره (مثل الصيغ الكيميائية H₂O)."
  },
  {
    id: 57,
    category: "HTML",
    question: "ما هو DOCTYPE في HTML5؟",
    options: [
      "<!DOCTYPE html>",
      "<!DOCTYPE HTML5>",
      "<DOCTYPE>",
      "<!DOC html>"
    ],
    correctAnswer: 0,
    explanation: "<!DOCTYPE html> هو التصريح القياسي لمستندات HTML5 ويجب أن يكون في أول سطر."
  },
  {
    id: 58,
    category: "HTML",
    question: "أي سمة تُستخدم لتعريف مُعرّف فريد لعنصر HTML؟",
    options: ["class", "id", "name", "identifier"],
    correctAnswer: 1,
    explanation: "السمة id تُستخدم لتعريف هوية فريدة للعنصر، لا يمكن تكرار نفس الـ id في الصفحة."
  },
  {
    id: 59,
    category: "HTML",
    question: "أي سمة تُستخدم لتعريف فئة لعنصر HTML؟",
    options: ["class", "id", "type", "category"],
    correctAnswer: 0,
    explanation: "السمة class تُستخدم لتعريف فئة أو أكثر للعنصر، ويمكن تكرارها لعدة عناصر لتطبيق نفس التنسيق."
  },
  {
    id: 60,
    category: "HTML",
    question: "كيف تُضيف أنماط CSS مباشرة داخل عنصر HTML؟",
    options: [
      "css='...'",
      "style='...'",
      "design='...'",
      "format='...'"
    ],
    correctAnswer: 1,
    explanation: "السمة style تُستخدم لإضافة أنماط CSS مضمنة (Inline CSS) للعنصر."
  },
  {
    id: 61,
    category: "HTML",
    question: "أي وسم يُستخدم لربط ملف CSS خارجي؟",
    options: ["<style>", "<css>", "<link>", "<stylesheet>"],
    correctAnswer: 2,
    explanation: "الوسم <link> مع السمة rel='stylesheet' يُستخدم لربط ملفات CSS الخارجية."
  },
  {
    id: 62,
    category: "HTML",
    question: "أين يوضع وسم <link> لربط CSS؟",
    options: [
      "في <body>",
      "في <head>",
      "في <footer>",
      "في أي مكان"
    ],
    correctAnswer: 1,
    explanation: "يجب وضع وسوم <link> داخل قسم <head> ليتم تحميل التنسيقات قبل عرض المحتوى."
  },
  {
    id: 63,
    category: "HTML",
    question: "أي وسم يُستخدم لإضافة JavaScript داخل HTML؟",
    options: ["<js>", "<javascript>", "<script>", "<code>"],
    correctAnswer: 2,
    explanation: "الوسم <script> يُستخدم لتضمين كود JavaScript أو الإشارة لملف JS خارجي."
  },
  {
    id: 64,
    category: "HTML",
    question: "أي سمة تُستخدم لربط ملف JavaScript خارجي؟",
    options: ["href", "src", "link", "file"],
    correctAnswer: 1,
    explanation: "السمة src داخل وسم <script> تحدد مسار ملف JavaScript الخارجي."
  },
  {
    id: 65,
    category: "HTML",
    question: "أي وسم يُعرّف معلومات وصفية (Metadata) عن المستند؟",
    options: ["<metadata>", "<info>", "<meta>", "<data>"],
    correctAnswer: 2,
    explanation: "الوسم <meta> يوفر بيانات وصفية حول المستند مثل الترميز، الكلمات المفتاحية، والمؤلف."
  },
  {
    id: 66,
    category: "HTML",
    question: "كيف تُحدد ترميز الحروف (Character Encoding) في HTML5؟",
    options: [
      "<meta encoding='UTF-8'>",
      "<meta charset='UTF-8'>",
      "<charset='UTF-8'>",
      "<encoding='UTF-8'>"
    ],
    correctAnswer: 1,
    explanation: "<meta charset='UTF-8'> يحدد ترميز الحروف ليكون UTF-8 وهو الترميز العالمي الموصى به."
  },
  {
    id: 67,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء قائمة تعريفات؟",
    options: ["<list>", "<dl>", "<def>", "<definition>"],
    correctAnswer: 1,
    explanation: "الوسم <dl> (Description List) يُستخدم كحاوية لقائمة المصطلحات وتعريفاتها."
  },
  {
    id: 68,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء مصطلح في قائمة التعريفات؟",
    options: ["<term>", "<dt>", "<dd>", "<definition>"],
    correctAnswer: 1,
    explanation: "الوسم <dt> (Description Term) يحدد المصطلح المراد تعريفه في القائمة."
  },
  {
    id: 69,
    category: "HTML",
    question: "أي وسم يُستخدم لإنشاء وصف في قائمة التعريفات؟",
    options: ["<desc>", "<dt>", "<dd>", "<definition>"],
    correctAnswer: 2,
    explanation: "الوسم <dd> (Description Data) يحتوي على شرح أو تعريف للمصطلح <dt>."
  },
  {
    id: 70,
    category: "HTML",
    question: "ما هو الغرض من سمة 'placeholder' في حقل الإدخال؟",
    options: [
      "تعيين قيمة افتراضية",
      "عرض نص توضيحي داخل الحقل",
      "تحديد نوع البيانات",
      "التحقق من صحة البيانات"
    ],
    correctAnswer: 1,
    explanation: "السمة placeholder تعرض نصاً باهتاً داخل الحقل كإرشاد للمستخدم (مثال: 'أدخل بريدك الإلكتروني')."
  },
  {
    id: 71,
    category: "HTML",
    question: "أي نوع إدخال يُستخدم لاختيار التاريخ في HTML5؟",
    options: [
      "type='calendar'",
      "type='date'",
      "type='day'",
      "type='datetime'"
    ],
    correctAnswer: 1,
    explanation: "input type='date' يظهر منتقي التاريخ (Calendar picker) للمستخدم."
  },
  {
    id: 72,
    category: "HTML",
    question: "أي نوع إدخال يُستخدم لاختيار اللون في HTML5؟",
    options: [
      "type='color'",
      "type='picker'",
      "type='colorpicker'",
      "type='palette'"
    ],
    correctAnswer: 0,
    explanation: "input type='color' يظهر أداة لاختيار اللون (Color Picker)."
  },
  {
    id: 73,
    category: "HTML",
    question: "أي نوع إدخال يُستخدم لإدخال البريد الإلكتروني؟",
    options: [
      "type='text'",
      "type='mail'",
      "type='email'",
      "type='e-mail'"
    ],
    correctAnswer: 2,
    explanation: "input type='email' مخصص للبريد الإلكتروني ويقوم بالتحقق من صحة التنسيق تلقائياً في بعض المتصفحات."
  },
  {
    id: 74,
    category: "HTML",
    question: "أي نوع إدخال يُستخدم لإدخال رقم؟",
    options: [
      "type='num'",
      "type='number'",
      "type='digit'",
      "type='numeric'"
    ],
    correctAnswer: 1,
    explanation: "input type='number' يقبل الأرقام فقط ويوفر عادة أزرار لزيادة وإنقاص القيمة."
  },
  {
    id: 75,
    category: "HTML",
    question: "أي سمة تُستخدم لتحديد عرض الصورة؟",
    options: ["size", "width", "w", "dimension"],
    correctAnswer: 1,
    explanation: "السمة width تحدد عرض الصورة بالبكسل."
  },
  {
    id: 76,
    category: "HTML",
    question: "أي سمة تُستخدم لتحديد ارتفاع الصورة؟",
    options: ["size", "h", "height", "dimension"],
    correctAnswer: 2,
    explanation: "السمة height تحدد ارتفاع الصورة بالبكسل."
  },
  {
    id: 77,
    category: "HTML",
    question: "ما هو الوسم الصحيح للمحتوى الرئيسي في HTML5؟",
    options: ["<content>", "<main>", "<primary>", "<body>"],
    correctAnswer: 1,
    explanation: "الوسم <main> يحدد المحتوى الرئيسي والفريد للصفحة، ويجب أن يكون هناك عنصر <main> واحد فقط."
  },
  {
    id: 78,
    category: "HTML",
    question: "أي وسم يُستخدم لعرض رسومات متجهة (SVG)؟",
    options: ["<vector>", "<graphic>", "<svg>", "<canvas>"],
    correctAnswer: 2,
    explanation: "الوسم <svg> (Scalable Vector Graphics) يُستخدم لتضمين رسومات متجهة قابلة للتكبير دون فقدان الجودة."
  },
  {
    id: 79,
    category: "HTML",
    question: "أي وسم يُستخدم لرسم الرسومات باستخدام JavaScript؟",
    options: ["<draw>", "<graphic>", "<canvas>", "<svg>"],
    correctAnswer: 2,
    explanation: "الوسم <canvas> يوفر مساحة للرسم النقطي (Bitmap) باستخدام JavaScript."
  },
  {
    id: 80,
    category: "HTML",
    question: "ما هي القيمة الافتراضية لسمة 'method' في النموذج؟",
    options: ["POST", "GET", "PUT", "DELETE"],
    correctAnswer: 1,
    explanation: "القيمة الافتراضية لـ method هي GET، والتي ترسل البيانات ملحقة بعنوان URL."
  },
  {
    id: 81,
    category: "HTML",
    question: "ما هو الـ Semantic HTML؟",
    options: [
      "وسوم HTML التي تعبر عن معناها ومحتواها بوضوح",
      "وسوم HTML التي تستخدم فقط للتصميم",
      "وسوم HTML التي يتم إنشاؤها بواسطة JavaScript",
      "وسوم HTML الخاصة بالرسومات المتحركة"
    ],
    correctAnswer: 0,
    explanation: "الـ Semantic HTML هو استخدام وسوم HTML التي تعبّر عن معناها ومحتواها بوضوح، وليس فقط عن شكلها.\n\nوسوم Semantic HTML أمثلة:\n- `<header>`: رأس الصفحة أو القسم\n- `<nav>`: شريط التنقل\n- `<main>`: المحتوى الرئيسي\n- `<section>`: قسم من الصفحة\n- `<article>`: محتوى مستقل\n- `<footer>`: تذييل الصفحة\n\nلماذا نستخدم Semantic HTML؟\n✅ تحسين SEO (محركات البحث تفهم المحتوى أفضل)\n✅ تحسين إمكانية الوصول (Screen Readers)\n✅ كود أوضح وأسهل صيانة\n✅ تنظيم أفضل لهيكل الصفحة",
    difficulty: "سهل"
  },
  // ==========================================
  // CSS SECTION (IDs 101-200)
  // Total: 100 Questions
  // ==========================================
  {
    id: 101,
    category: "CSS",
    question: "ما معنى الاختصار CSS؟",
    options: [
      "Creative Style Sheets",
      "Cascading Style Sheets",
      "Computer Style Sheets",
      "Colorful Style Sheets"
    ],
    correctAnswer: 1,
    explanation: "CSS تعني Cascading Style Sheets وهي لغة تستخدم لتنسيق صفحات الويب."
  },
  {
    id: 102,
    category: "CSS",
    question: "أي خاصية CSS تُستخدم لتغيير لون خلفية عنصر؟",
    options: ["color", "bg-color", "background-color", "background-style"],
    correctAnswer: 2,
    explanation: "خاصية background-color هي المسؤولة عن تحديد لون خلفية العنصر."
  },
  {
    id: 103,
    category: "CSS",
    question: "أي خاصية CSS تُستخدم لتغيير لون النص؟",
    options: ["text-color", "font-color", "color", "fg-color"],
    correctAnswer: 2,
    explanation: "خاصية color هي المستخدمة لتغيير لون النص نفسه."
  },
  {
    id: 104,
    category: "CSS",
    question: "ما هي الخاصية المسؤولة عن حجم الخط؟",
    options: ["text-size", "font-size", "size", "font-height"],
    correctAnswer: 1,
    explanation: "خاصية font-size تحدد حجم خط النص."
  },
  {
    id: 105,
    category: "CSS",
    question: "كيف تجعل النص غامقاً (Bold) في CSS؟",
    options: ["font-style: bold", "font-weight: bold", "text-decoration: bold", "text-weight: bold"],
    correctAnswer: 1,
    explanation: "خاصية font-weight تتحكم في سمك الخط، وقيمة bold تجعله غامقاً."
  },
  {
    id: 106,
    category: "CSS",
    question: "أي خاصية تُستخدم لمحاذاة النص في المنتصف؟",
    options: ["text-align: center", "align: center", "font-align: center", "justify: center"],
    correctAnswer: 0,
    explanation: "خاصية text-align بقيمة center تقوم بتوسط النص أفقيًا داخل الحاوية."
  },
  {
    id: 107,
    category: "CSS",
    question: "كيف تضيف مسافة داخلية (Padding) للعنصر؟",
    options: ["margin", "space", "padding", "border-spacing"],
    correctAnswer: 2,
    explanation: "Padding هي المسافة الداخلية بين محتوى العنصر وحدوده."
  },
  {
    id: 108,
    category: "CSS",
    question: "كيف تضيف مسافة خارجية (Margin) للعنصر؟",
    options: ["margin", "padding", "spacing", "offset"],
    correctAnswer: 0,
    explanation: "Margin هي المسافة الخارجية التي تفصل العنصر عن العناصر المحيطة به."
  },
  {
    id: 109,
    category: "CSS",
    question: "ما هي الصيغة الصحيحة للإشارة إلى عنصر بـ ID اسمه 'header'؟",
    options: [".header", "#header", "header", "*header"],
    correctAnswer: 1,
    explanation: "في CSS، نستخدم الرمز # للإشارة إلى الـ ID."
  },
  {
    id: 110,
    category: "CSS",
    question: "ما هي الصيغة الصحيحة للإشارة إلى عنصر بـ Class اسمه 'menu'؟",
    options: [".menu", "#menu", "menu", "%menu"],
    correctAnswer: 0,
    explanation: "في CSS، نستخدم النقطة . للإشارة إلى الـ Class."
  },
  {
    id: 111,
    category: "CSS",
    question: "أي خاصية تتحكم في ظهور أو إخفاء العنصر مع حجز مكانه؟",
    options: ["display: none", "visibility: hidden", "opacity: 0", "hidden: true"],
    correctAnswer: 1,
    explanation: "visibility: hidden تخفي العنصر ولكنها تحافظ على المساحة التي يشغلها في الصفحة."
  },
  {
    id: 112,
    category: "CSS",
    question: "أي خاصية تخفي العنصر تماماً وتزيله من تدفق الصفحة؟",
    options: ["display: none", "visibility: hidden", "opacity: 0", "remove: true"],
    correctAnswer: 0,
    explanation: "display: none تزيل العنصر تماماً وكأنه غير موجود في الصفحة."
  },
  {
    id: 113,
    category: "CSS",
    question: "كيف تجعل القائمة تظهر بشكل أفقي باستخدام Flexbox؟",
    options: ["display: flex", "list-style: horizontal", "display: inline", "float: left"],
    correctAnswer: 0,
    explanation: "تطبيق display: flex على الحاوية يجعل العناصر الأبناء تصطف أفقياً بشكل افتراضي."
  },
  {
    id: 114,
    category: "CSS",
    question: "أي خاصية في Flexbox تتحكم في المحاذاة الأفقية؟",
    options: ["align-items", "justify-content", "flex-align", "text-align"],
    correctAnswer: 1,
    explanation: "justify-content تتحكم في توزيع المساحات والمحاذاة على المحور الرئيسي (الأفقي عادةً)."
  },
  {
    id: 115,
    category: "CSS",
    question: "أي خاصية في Flexbox تتحكم في المحاذاة العمودية؟",
    options: ["align-items", "justify-content", "vertical-align", "flex-direction"],
    correctAnswer: 0,
    explanation: "align-items تتحكم في محاذاة العناصر على المحور الثانوي (العمودي عادةً)."
  },
  {
    id: 116,
    category: "CSS",
    question: "كيف تضيف حدوداً (Border) للعنصر؟",
    options: ["border-style", "border-width", "border-color", "border"],
    correctAnswer: 3,
    explanation: "الخاصية المختصرة border تمكنك من تحديد السمك والنمط واللون في سطر واحد."
  },
  {
    id: 117,
    category: "CSS",
    question: "أي خاصية تجعل زوايا العنصر دائرية؟",
    options: ["border-round", "border-radius", "corner-radius", "border-circle"],
    correctAnswer: 1,
    explanation: "border-radius تستخدم لتدوير زوايا العنصر."
  },
  {
    id: 118,
    category: "CSS",
    question: "كيف تضيف ظلاً (Shadow) لصندوق العنصر؟",
    options: ["box-shadow", "shadow", "drop-shadow", "element-shadow"],
    correctAnswer: 0,
    explanation: "box-shadow هي الخاصية المسؤولة عن إضافة تأثير الظل للعناصر (Boxes)."
  },
  {
    id: 119,
    category: "CSS",
    question: "أي خاصية تُستخدم لإضافة ظل للنص؟",
    options: ["font-shadow", "text-shadow", "word-shadow", "shadow-text"],
    correctAnswer: 1,
    explanation: "text-shadow تُستخدم لإضافة تأثير الظل للنصوص."
  },
  {
    id: 120,
    category: "CSS",
    question: "ما هي القيمة الافتراضية لخاصية position؟",
    options: ["relative", "absolute", "fixed", "static"],
    correctAnswer: 3,
    explanation: "static هي الوضعية الافتراضية لجميع عناصر HTML."
  },
  {
    id: 121,
    category: "CSS",
    question: "أي قيمة لـ position تجعل العنصر يتحرك بالنسبة لمكانه الأصلي؟",
    options: ["absolute", "relative", "fixed", "sticky"],
    correctAnswer: 1,
    explanation: "relative تسمح بتحريك العنصر بالنسبة لموقعه الطبيعي دون التأثير على العناصر الأخرى."
  },
  {
    id: 122,
    category: "CSS",
    question: "أي قيمة لـ position تجعل العنصر ثابتاً بالنسبة لنافذة المتصفح؟",
    options: ["static", "absolute", "fixed", "relative"],
    correctAnswer: 2,
    explanation: "fixed تثبت العنصر في مكان محدد بالنسبة للشاشة (Viewport) ولا يتحرك عند التمرير."
  },
  {
    id: 123,
    category: "CSS",
    question: "ما هي الخاصية التي تتحكم في ترتيب الطبقات (الظهور فوق بعضها)؟",
    options: ["layer-index", "z-index", "stack-order", "position-index"],
    correctAnswer: 1,
    explanation: "z-index تحدد ترتيب تكديس العناصر؛ العنصر ذو القيمة الأعلى يظهر فوق الآخر."
  },
  {
    id: 124,
    category: "CSS",
    question: "كيف تمنع تكرار صورة الخلفية؟",
    options: ["background-repeat: no-repeat", "background-loop: none", "repeat: no", "background-tile: none"],
    correctAnswer: 0,
    explanation: "background-repeat: no-repeat تمنع تكرار الصورة وتظهرها مرة واحدة فقط."
  },
  {
    id: 125,
    category: "CSS",
    question: "أي خاصية تحدد صورة الخلفية؟",
    options: ["background-img", "background-image", "background-source", "image-bg"],
    correctAnswer: 1,
    explanation: "background-image تستخدم لتعيين صورة كخلفية للعنصر."
  },
  {
    id: 126,
    category: "CSS",
    question: "كيف تجعل صورة الخلفية تغطي العنصر بالكامل؟",
    options: ["background-size: cover", "background-size: contain", "background-size: 100%", "background-fit: fill"],
    correctAnswer: 0,
    explanation: "background-size: cover تضمن تغطية كامل مساحة العنصر بالصورة مع الحفاظ على نسبتها."
  },
  {
    id: 127,
    category: "CSS",
    question: "أي خاصية تتحكم في شفافية العنصر؟",
    options: ["transparent", "opacity", "visibility", "alpha"],
    correctAnswer: 1,
    explanation: "opacity تحدد مستوى شفافية العنصر من 0.0 (شفاف تماماً) إلى 1.0 (معتم)."
  },
  {
    id: 128,
    category: "CSS",
    question: "كيف تزيل الخط الموجود تحت الروابط؟",
    options: ["text-decoration: none", "text-style: none", "font-decoration: none", "underline: none"],
    correctAnswer: 0,
    explanation: "text-decoration: none تستخدم لإزالة الزخارف مثل الخط السفلي من الروابط."
  },
  {
    id: 129,
    category: "CSS",
    question: "أي خاصية تحول النص إلى حروف كبيرة (Uppercase)؟",
    options: ["text-style: uppercase", "text-transform: uppercase", "font-case: upper", "text-caps: all"],
    correctAnswer: 1,
    explanation: "text-transform: uppercase تحول جميع أحرف النص إلى حالة الأحرف الكبيرة."
  },
  {
    id: 130,
    category: "CSS",
    question: "ما هي الخاصية المسؤولة عن ارتفاع السطر؟",
    options: ["text-height", "line-height", "font-height", "spacing-height"],
    correctAnswer: 1,
    explanation: "line-height تحدد المسافة العمودية بين سطور النص."
  },
  {
    id: 131,
    category: "CSS",
    question: "أي خاصية تحدد نوع الخط (Font Family)؟",
    options: ["font-type", "font-name", "font-family", "text-font"],
    correctAnswer: 2,
    explanation: "font-family تحدد نوع الخط المستخدم للنص."
  },
  {
    id: 132,
    category: "CSS",
    question: "كيف تجعل العنصر يطفو لليسار؟",
    options: ["align: left", "float: left", "position: left", "move: left"],
    correctAnswer: 1,
    explanation: "float: left تجعل العنصر يطفو إلى أقصى اليسار وتلتف العناصر الأخرى حوله."
  },
  {
    id: 133,
    category: "CSS",
    question: "كيف تلغي تأثير الـ Float؟",
    options: ["clear: both", "float: none", "stop: float", "overflow: hidden"],
    correctAnswer: 0,
    explanation: "clear: both تمنع العناصر من الالتفاف حول العناصر العائمة السابقة."
  },
  {
    id: 134,
    category: "CSS",
    question: "أي خاصية تستخدم للتحكم في ما يحدث عند تجاوز المحتوى حجم العنصر؟",
    options: ["clip", "overflow", "scroll", "resize"],
    correctAnswer: 1,
    explanation: "overflow تحدد كيفية التعامل مع المحتوى الذي يتجاوز أبعاد العنصر (hidden, scroll, auto)."
  },
  {
    id: 135,
    category: "CSS",
    question: "كيف تحدد أقصى عرض للعنصر؟",
    options: ["width-max", "max-width", "limit-width", "top-width"],
    correctAnswer: 1,
    explanation: "max-width تمنع العنصر من أن يصبح أعرض من القيمة المحددة."
  },
  {
    id: 136,
    category: "CSS",
    question: "أي خاصية في Grid تحدد عدد الأعمدة؟",
    options: ["grid-columns", "grid-template-columns", "grid-col-count", "columns"],
    correctAnswer: 1,
    explanation: "grid-template-columns تُستخدم لتعريف عدد وعرض الأعمدة في نظام الشبكة (Grid)."
  },
  {
    id: 137,
    category: "CSS",
    question: "ما هي وحدة القياس التي تعتمد على حجم الشاشة (Viewport Width)؟",
    options: ["px", "em", "vw", "rem"],
    correctAnswer: 2,
    explanation: "vw تعني Viewport Width وتمثل نسبة مئوية من عرض نافذة المتصفح."
  },
  {
    id: 138,
    category: "CSS",
    question: "أي وحدة قياس تعتمد على حجم خط العنصر الأب؟",
    options: ["rem", "em", "px", "pt"],
    correctAnswer: 1,
    explanation: "em هي وحدة نسبية تعتمد على حجم خط العنصر الأب المباشر."
  },
  {
    id: 139,
    category: "CSS",
    question: "أي وحدة قياس تعتمد على حجم خط العنصر الجذري (html)؟",
    options: ["rem", "em", "px", "%"],
    correctAnswer: 0,
    explanation: "rem (root em) تعتمد دائماً على حجم الخط في العنصر الجذري <html>."
  },
  {
    id: 140,
    category: "CSS",
    question: "كيف تطبق تنسيقاً عند مرور الماوس على العنصر؟",
    options: [":hover", ":mouse", ":active", ":focus"],
    correctAnswer: 0,
    explanation: ":hover هو Pseudo-class يطبق التنسيقات عند تحويم مؤشر الماوس فوق العنصر."
  },
  {
    id: 141,
    category: "CSS",
    question: "أي خاصية تستخدم لعمل انتقال سلس للتأثيرات (Transition)؟",
    options: ["animate", "transition", "transform", "smooth"],
    correctAnswer: 1,
    explanation: "transition تسمح بتغيير قيم الخصائص بسلاسة خلال فترة زمنية محددة."
  },
  {
    id: 142,
    category: "CSS",
    question: "كيف تقوم بتدوير عنصر 45 درجة؟",
    options: ["rotate(45deg)", "transform: rotate(45deg)", "turn: 45", "spin: 45deg"],
    correctAnswer: 1,
    explanation: "transform: rotate(45deg) هي الطريقة الصحيحة لتدوير العنصر."
  },
  {
    id: 143,
    category: "CSS",
    question: "أي خاصية تستخدم لتكبير أو تصغير العنصر؟",
    options: ["resize", "scale", "zoom", "transform: scale()"],
    correctAnswer: 3,
    explanation: "transform: scale() تُستخدم لتغيير حجم العنصر (تكبير أو تصغير)."
  },
  {
    id: 144,
    category: "CSS",
    question: "ما هو Media Query؟",
    options: [
      "أداة لاستعلام قاعدة البيانات",
      "تقنية لتطبيق CSS بناءً على خصائص الجهاز (مثل عرض الشاشة)",
      "طريقة لإضافة ميديا",
      "نوع من أنواع الخطوط"
    ],
    correctAnswer: 1,
    explanation: "@media تُستخدم لتطبيق تنسيقات مختلفة لأجهزة مختلفة (تصميم متجاوب)."
  },
  {
    id: 145,
    category: "CSS",
    question: "كيف تختار العنصر الأول من نوعه داخل حاوية؟",
    options: [":first-child", ":first", ":child-one", ":initial"],
    correctAnswer: 0,
    explanation: ":first-child يختار العنصر الذي يكون أول ابن لأبيه."
  },
  {
    id: 146,
    category: "CSS",
    question: "كيف تختار العنصر الأخير من نوعه؟",
    options: [":last-child", ":last", ":end-child", ":final"],
    correctAnswer: 0,
    explanation: ":last-child يختار العنصر الذي يكون آخر ابن لأبيه."
  },
  {
    id: 147,
    category: "CSS",
    question: "ما الفرق بين display: inline و display: block؟",
    options: [
      "inline يبدأ سطر جديد، block لا يبدأ",
      "block يأخذ العرض الكامل ويبدأ سطر جديد، inline يأخذ عرض المحتوى فقط",
      "لا يوجد فرق",
      "inline للعناصر الكبيرة و block للصغيرة"
    ],
    correctAnswer: 1,
    explanation: "عناصر Block تأخذ عرض السطر بالكامل، بينما Inline تأخذ مساحة محتواها فقط ولا تبدأ سطرًا جديدًا."
  },
  {
    id: 148,
    category: "CSS",
    question: "أي خاصية تستخدم لزيادة المسافة بين الأحرف؟",
    options: ["word-spacing", "letter-spacing", "char-spacing", "text-indent"],
    correctAnswer: 1,
    explanation: "letter-spacing تتحكم في المسافة بين حروف النص."
  },
  {
    id: 149,
    category: "CSS",
    question: "أي خاصية تستخدم لزيادة المسافة بين الكلمات؟",
    options: ["word-spacing", "letter-spacing", "text-gap", "word-gap"],
    correctAnswer: 0,
    explanation: "word-spacing تتحكم في المسافة بين الكلمات."
  },
  {
    id: 150,
    category: "CSS",
    question: "ماذا تعني !important في CSS؟",
    options: [
      "تعليق هام",
      "خطأ في الكود",
      "إعطاء الأولوية القصوى للقاعدة وتجاهل القواعس الأخرى",
      "تحذير للمتصفح"
    ],
    correctAnswer: 2,
    explanation: "!important تجعل القاعدة تتغلب على أي قواعس أخرى حتى لو كانت أكثر تحديداً."
  },
  {
    id: 151,
    category: "CSS",
    question: "أي خاصية تحدد المسافة بين العناصر في Flexbox أو Grid؟",
    options: ["margin", "space", "gap", "gutter"],
    correctAnswer: 2,
    explanation: "gap (أو grid-gap سابقاً) تحدد المسافة بين الصفوف والأعمدة في Grid و Flexbox."
  },
  {
    id: 152,
    category: "CSS",
    question: "كيف تجعل العناصر تلتف لسطر جديد في Flexbox؟",
    options: ["flex-wrap: wrap", "flex-flow: new-line", "flex-direction: column", "wrap: true"],
    correctAnswer: 0,
    explanation: "flex-wrap: wrap تسمح للعناصر بالانتقال لسطر جديد إذا لم تكف المساحة."
  },
  {
    id: 153,
    category: "CSS",
    question: "ما هي القيمة الافتراضية لـ flex-direction؟",
    options: ["column", "row", "row-reverse", "column-reverse"],
    correctAnswer: 1,
    explanation: "row هي القيمة الافتراضية، حيث تترتب العناصر أفقياً من اليسار لليمين (أو العكس حسب اللغة)."
  },
  {
    id: 154,
    category: "CSS",
    question: "أي خاصية تستخدم لإنشاء محتوى قبل العنصر (Pseudo-element)؟",
    options: ["::before", "::after", "::start", "::first"],
    correctAnswer: 0,
    explanation: "::before يُستخدم لإدراج محتوى قبل محتوى العنصر المختار."
  },
  {
    id: 155,
    category: "CSS",
    question: "أي خاصية تستخدم لإنشاء محتوى بعد العنصر (Pseudo-element)؟",
    options: ["::after", "::before", "::end", "::last"],
    correctAnswer: 0,
    explanation: "::after يُستخدم لإدراج محتوى بعد محتوى العنصر المختار."
  },
  {
    id: 156,
    category: "CSS",
    question: "كيف تحدد نمط خط الحدود ليكون منقطاً؟",
    options: ["border-style: dotted", "border-style: dashed", "border-style: solid", "border-style: point"],
    correctAnswer: 0,
    explanation: "dotted تجعل الحدود عبارة عن نقاط."
  },
  {
    id: 157,
    category: "CSS",
    question: "كيف تحدد نمط خط الحدود ليكون متقطعاً (شرطات)؟",
    options: ["border-style: dotted", "border-style: dashed", "border-style: solid", "border-style: line"],
    correctAnswer: 1,
    explanation: "dashed تجعل الحدود عبارة عن شرطات متقطعة."
  },
  {
    id: 158,
    category: "CSS",
    question: "أي خاصية تجعل العنصر غير قابل للنقر (يتم تجاهل أحداث الماوس)؟",
    options: ["user-select: none", "pointer-events: none", "click: disabled", "cursor: none"],
    correctAnswer: 1,
    explanation: "pointer-events: none تجعل العنصر يمرر أحداث الماوس للعناصر التي تحته ولا يتفاعل معها."
  },
  {
    id: 159,
    category: "CSS",
    question: "كيف تغير شكل مؤشر الماوس عند المرور على زر؟",
    options: ["mouse: hand", "cursor: pointer", "pointer: hand", "cursor: hand"],
    correctAnswer: 1,
    explanation: "cursor: pointer تغير شكل المؤشر ليد للإشارة إلى أن العنصر قابل للنقر."
  },
  {
    id: 160,
    category: "CSS",
    question: "أي خاصية تستخدم لإخفاء الجزء الزائد من النص بنقاط (...)؟",
    options: ["text-overflow: ellipsis", "overflow: hidden", "text-cut: true", "word-break: break-all"],
    correctAnswer: 0,
    explanation: "text-overflow: ellipsis تضيف ثلاث نقاط (...) للدلالة على وجود نص مخفي (يتطلب overflow: hidden)."
  },
  {
    id: 161,
    category: "CSS",
    question: "ماذا يفعل الصندوق (Box Model) في CSS؟",
    options: [
      "يرسم صندوقاً حول الصفحة",
      "يصف كيف يتم حساب المساحة التي يشغلها العنصر (margin, border, padding, content)",
      "أداة لتصميم الشعارات",
      "نموذج لترتيب الملفات"
    ],
    correctAnswer: 1,
    explanation: "Box Model هو المفهوم الأساسي الذي يصف تكوين كل عنصر HTML من محتوى، حاشية، حدود، وهامش."
  },
  {
    id: 162,
    category: "CSS",
    question: "كيف تجعل الخلفية ثابتة أثناء التمرير؟",
    options: ["background-attachment: fixed", "background-position: fixed", "background-scroll: no", "background-fix: true"],
    correctAnswer: 0,
    explanation: "background-attachment: fixed تجعل صورة الخلفية ثابتة ولا تتحرك مع تمرير الصفحة."
  },
  {
    id: 163,
    category: "CSS",
    question: "أي خاصية تحدد الحد الأدنى للارتفاع؟",
    options: ["min-height", "height-min", "low-height", "limit-height"],
    correctAnswer: 0,
    explanation: "min-height تضمن أن العنصر لن يقل ارتفاعه عن قيمة معينة."
  },
  {
    id: 164,
    category: "CSS",
    question: "أي خاصية تحدد الحد الأقصى للارتفاع؟",
    options: ["max-height", "height-max", "top-height", "cap-height"],
    correctAnswer: 0,
    explanation: "max-height تضمن أن العنصر لن يزيد ارتفاعه عن قيمة معينة."
  },
  {
    id: 165,
    category: "CSS",
    question: "كيف تقوم بتوسيط عنصر (block) أفقيًا باستخدام Margin؟",
    options: ["margin: 0 auto", "margin: center", "margin-x: auto", "align: center"],
    correctAnswer: 0,
    explanation: "margin: 0 auto تعطي هوامش تلقائية (متساوية) من اليمين واليسار، مما يوسط العنصر."
  },
  {
    id: 166,
    category: "CSS",
    question: "ما هو الـ Specificity في CSS؟",
    options: [
      "سرعة تحميل الصفحة",
      "نظام يحدد أي القواعس يتم تطبيقها عند التعارض (الأولوية)",
      "تحديد نوع الملف",
      "طريقة لكتابة التعليقات"
    ],
    correctAnswer: 1,
    explanation: "Specificity (الخصوصية) هي الوزن المعطى لمحدد CSS والذي يقرر المتصفح بناءً عليه أي نمط سيطبق."
  },
  {
    id: 167,
    category: "CSS",
    question: "أي محدد له أولوية (Specificity) أعلى؟",
    options: ["ID Selector (#id)", "Class Selector (.class)", "Type Selector (div)", "Universal Selector (*)"],
    correctAnswer: 0,
    explanation: "محدد الـ ID (#) له وزن أعلى من Class و Type."
  },
  {
    id: 168,
    category: "CSS",
    question: "كيف تطبق نمطاً على العنصر عند التركيز عليه (مثلاً عند الكتابة في حقل)؟",
    options: [":focus", ":active", ":hover", ":selected"],
    correctAnswer: 0,
    explanation: ":focus هو Pseudo-class يطبق عند تركيز المستخدم على العنصر (مثل النقر داخل حقل إدخال)."
  },
  {
    id: 169,
    category: "CSS",
    question: "أي خاصية تستخدم لعمل تدرج لوني (Gradient)؟",
    options: ["background-color", "background-image: linear-gradient()", "color-gradient", "fill-gradient"],
    correctAnswer: 1,
    explanation: "التدرجات اللونية تُعامل كصور في CSS، وتُضاف عبر خاصية background-image."
  },
  {
    id: 170,
    category: "CSS",
    question: "ماذا تفعل box-sizing: border-box؟",
    options: [
      "تضيف حدوداً للصندوق",
      "تجعل حساب العرض والارتفاع يشمل الـ Padding والـ Border",
      "تحذف الحدود",
      "تجعل الصندوق مربعاً"
    ],
    correctAnswer: 1,
    explanation: "border-box تسهل التصميم بجعل العرض الكلي يشمل الحشو والحدود، فلا يزيد حجم العنصر عن المحدد."
  },
  {
    id: 171,
    category: "CSS",
    question: "كيف تحدد شفافية اللون باستخدام RGBA؟",
    options: ["rgba(255, 0, 0, 0.5)", "rgb(255, 0, 0, 50)", "color(255, 0, 0, 0.5)", "alpha(255, 0, 0)"],
    correctAnswer: 0,
    explanation: "القيمة الرابعة في rgba تمثل قناة ألفا (Alpha) للشفافية (من 0 لـ 1)."
  },
  {
    id: 172,
    category: "CSS",
    question: "أي خاصية تسمح بتغيير مكان العنصر باستخدام top, left, right, bottom؟",
    options: ["display", "position", "float", "align"],
    correctAnswer: 1,
    explanation: "خاصية position (بقيم غير static) تُفعّل استخدام top, bottom, left, right."
  },
  {
    id: 173,
    category: "CSS",
    question: "كيف تقوم بمحاذاة النص لليمين؟",
    options: ["text-align: right", "align: right", "float: right", "text-pos: right"],
    correctAnswer: 0,
    explanation: "text-align: right تحاذي محتوى النص إلى الجهة اليمنى."
  },
  {
    id: 174,
    category: "CSS",
    question: "أي دالة تستخدم لحساب القيم في CSS؟",
    options: ["calc()", "math()", "count()", "sum()"],
    correctAnswer: 0,
    explanation: "دالة calc() تسمح بإجراء عمليات حسابية لتحديد قيم خصائص CSS (مثلاً: width: calc(100% - 20px))."
  },
  {
    id: 175,
    category: "CSS",
    question: "أي خاصية تحدد كيفية عرض المسافات البيضاء في النص؟",
    options: ["white-space", "text-space", "spacing", "line-break"],
    correctAnswer: 0,
    explanation: "white-space تتحكم في التفاف النص وكيفية التعامل مع المسافات الفارغة (مثل nowrap, pre)."
  },
  {
    id: 176,
    category: "CSS",
    question: "كيف تطبق تنسيقاً على العنصر الأول في الصفحة فقط؟",
    options: ["body:first-child", ":root", "html:first", "top-element"],
    correctAnswer: 0,
    explanation: "يعتمد السياق، لكن :first-child يختار الابن الأول. لتنسيق أول عنصر في body يمكن استخدام body > :first-child."
  },
  {
    id: 177,
    category: "CSS",
    question: "أي خاصية تستخدم لإخفاء العنصر من قارئ الشاشة فقط؟",
    options: ["sr-only (class)", "display: none", "visibility: hidden", "opacity: 0"],
    correctAnswer: 0,
    explanation: "عادة ما نستخدم class مخصص (مثل .sr-only) بأبعاد 0 ليكون متاحاً للقارئ ومخفياً بصرياً، لأن display:none يخفيه عن الجميع."
  },
  {
    id: 178,
    category: "CSS",
    question: "ما هي المتغيرات في CSS (Custom Properties)؟",
    options: [
      "var myColor = red;",
      "$color: red;",
      "--main-color: red;",
      "@color: red;"
    ],
    correctAnswer: 2,
    explanation: "متغيرات CSS تبدأ بشرطتين -- (مثال: --main-color) وتستخدم دالة var() لاستدعائها."
  },
  {
    id: 179,
    category: "CSS",
    question: "أي خاصية تستخدم لتحديد اتجاه الظل في box-shadow؟",
    options: [
      "الإحداثيات X و Y (القيمتان الأولى والثانية)",
      "خاصية direction",
      "زاوية angle",
      "لا يمكن تحديد الاتجاه"
    ],
    correctAnswer: 0,
    explanation: "box-shadow: 10px 5px ...; القيمة الأولى للإزاحة الأفقية والثانية للعمودية."
  },
  {
    id: 180,
    category: "CSS",
    question: "كيف تجعل التصميم متجاوباً (Responsive)؟",
    options: [
      "استخدام Media Queries ووحدات نسبية (%, rem)",
      "استخدام جداول HTML",
      "استخدام JavaScript فقط",
      "تثبيت العرض بالبكسل"
    ],
    correctAnswer: 0,
    explanation: "التصميم المتجاوب يعتمد بشكل أساسي على Media Queries لتغيير التنسيق حسب حجم الشاشة واستخدام وحدات مرنة."
  },
  {
    id: 181,
    category: "CSS",
    question: "أي قيمة للخاصية display تجعل العنصر يختفي ولكنه يبقى في شجرة الـ DOM؟",
    options: [
      "display: none",
      "visibility: hidden",
      "display: inline",
      "display: hidden"
    ],
    correctAnswer: 0,
    explanation: "display: none تخفي العنصر وتزيله من التدفق البصري للصفحة، لكنه يظل موجوداً في الـ DOM."
  },
  {
    id: 182,
    category: "CSS",
    question: "ما هو الـ vendor prefix الخاص بمتصفحات WebKit (مثل Chrome و Safari)؟",
    options: ["-moz-", "-o-", "-webkit-", "-ms-"],
    correctAnswer: 2,
    explanation: "-webkit- هو الـ prefix المستخدم لمتصفحات تعتمد محرك WebKit مثل كروم وسفاري."
  },
  {
    id: 183,
    category: "CSS",
    question: "أي خاصية تستخدم للتحكم في كيفية تصغير العنصر في Flexbox؟",
    options: ["flex-grow", "flex-shrink", "flex-basis", "flex-size"],
    correctAnswer: 1,
    explanation: "flex-shrink تحدد مدى قابلية العنصر للتقلص إذا كانت المساحة غير كافية."
  },
  {
    id: 184,
    category: "CSS",
    question: "أي خاصية تستخدم للتحكم في كيفية تكبير العنصر في Flexbox؟",
    options: ["flex-shrink", "flex-basis", "flex-grow", "flex-expand"],
    correctAnswer: 2,
    explanation: "flex-grow تحدد مدى قابلية العنصر للتمدد لملء المساحة المتاحة."
  },
  {
    id: 185,
    category: "CSS",
    question: "ما هي الوظيفة الأساسية لـ normalize.css أو reset.css؟",
    options: [
      "إضافة ألوان جميلة للموقع",
      "توحيد ظهور العناصر عبر المتصفحات المختلفة",
      "زيادة سرعة التحميل",
      "تحويل CSS إلى SASS"
    ],
    correctAnswer: 1,
    explanation: "ملفات Reset أو Normalize تهدف لتقليل الفروقات في التنسيقات الافتراضية بين المتصفحات."
  },
  {
    id: 186,
    category: "CSS",
    question: "كيف تقوم بتحديد العناصر التي تحتوي على خاصية title؟",
    options: ["[title]", ".title", "#title", "title{}"],
    correctAnswer: 0,
    explanation: "Attribute Selector [title] يختار جميع العناصر التي تملك السمة title."
  },
  {
    id: 187,
    category: "CSS",
    question: "كيف تختار input من نوع checkbox فقط؟",
    options: ["input.checkbox", "input[type='checkbox']", "input:checkbox", "#checkbox"],
    correctAnswer: 1,
    explanation: "input[type='checkbox'] هو Attribute Selector يحدد المدخلات التي نوعها checkbox."
  },
  {
    id: 188,
    category: "CSS",
    question: "ماذا تعني الوحدة ch في CSS؟",
    options: [
      "ارتفاع الحرف",
      "عرض الرقم 0 في الخط الحالي",
      "عرض الشاشة",
      "قناة لونية"
    ],
    correctAnswer: 1,
    explanation: "ch هي وحدة تساوي عرض الرقم '0' (zero) في الخط والحجم المستخدمين حالياً."
  },
  {
    id: 189,
    category: "CSS",
    question: "أي خاصية تستخدم لإضافة فلاتر (مثل الضبابية أو السطوع) للعنصر؟",
    options: ["filter", "effect", "blur", "brightness"],
    correctAnswer: 0,
    explanation: "خاصية filter تمكنك من تطبيق تأثيرات رسومية مثل blur, brightness, contrast."
  },
  {
    id: 190,
    category: "CSS",
    question: "كيف تجعل الصفحة تمرر بسلاسة عند النقر على رابط داخلي (Anchor)؟",
    options: ["scroll-behavior: smooth", "scroll: smooth", "transition: scroll", "animate: scroll"],
    correctAnswer: 0,
    explanation: "توضع scroll-behavior: smooth عادة في html {} لتفعيل التمرير السلس في كامل الصفحة."
  },
  {
    id: 191,
    category: "CSS",
    question: "أي خاصية تستخدم للتحكم في شكل العنصر (قص جزء منه)؟",
    options: ["clip-path", "cut-out", "shape-outside", "mask-image"],
    correctAnswer: 0,
    explanation: "clip-path تسمح بقص العنصر بأشكال هندسية مختلفة (دائرة، مضلع، إلخ)."
  },
  {
    id: 192,
    category: "CSS",
    question: "ما هي القيمة الافتراضية لخاصية box-sizing؟",
    options: ["border-box", "content-box", "padding-box", "margin-box"],
    correctAnswer: 1,
    explanation: "content-box هي القيمة الافتراضية، حيث لا يشمل العرض المحدد الحشو أو الحدود."
  },
  {
    id: 193,
    category: "CSS",
    question: "أي خاصية في Grid تستخدم لتسمية المناطق (Areas)؟",
    options: ["grid-area-names", "grid-template-areas", "grid-names", "area-template"],
    correctAnswer: 1,
    explanation: "grid-template-areas تسمح بتعريف تخطيط الشبكة باستخدام أسماء معينة للمناطق."
  },
  {
    id: 194,
    category: "CSS",
    question: "كيف تقوم بتطبيق نمط على كل صفوف الجدول الزوجية؟",
    options: ["tr:nth-child(odd)", "tr:nth-child(even)", "tr:every-2", "tr:second"],
    correctAnswer: 1,
    explanation: ":nth-child(even) تختار العناصر التي ترتيبها زوجي (2, 4, 6...)."
  },
  {
    id: 195,
    category: "CSS",
    question: "أي دالة تستخدم لاستخدام قيمة متغير CSS؟",
    options: ["get()", "var()", "set()", "$()"],
    correctAnswer: 1,
    explanation: "var(--variable-name) هي الطريقة القياسية لاستدعاء قيمة متغير CSS."
  },
  {
    id: 196,
    category: "CSS",
    question: "أي خاصية تحدد طريقة دمج خلفية العنصر مع خلفية العنصر الأب؟",
    options: ["mix-blend-mode", "background-blend-mode", "blend-mode", "opacity-mode"],
    correctAnswer: 0,
    explanation: "mix-blend-mode تحدد كيفية دمج محتوى العنصر مع الخلفية التي تقع تحته."
  },
  {
    id: 197,
    category: "CSS",
    question: "أي خاصية تستخدم للتحكم في مظهر شريط التمرير (في المتصفحات الداعمة)؟",
    options: ["scrollbar-color", "scroll-style", "overflow-style", "bar-color"],
    correctAnswer: 0,
    explanation: "scrollbar-color (و scrollbar-width) هي خصائص قياسية حديثة لتنسيق شريط التمرير."
  },
  {
    id: 198,
    category: "CSS",
    question: "ماذا تفعل القيمة 'sticky' للخاصية position؟",
    options: [
      "تجعل العنصر يلتصق أسفل الصفحة",
      "تجعل العنصر يتصرف كـ relative حتى يصل لنقطة معينة ثم يصبح fixed",
      "تثبت العنصر في مكانه ولا يتحرك أبداً",
      "لا يوجد قيمة بهذا الاسم"
    ],
    correctAnswer: 1,
    explanation: "sticky تجعل العنصر يلتصق (يصبح مثبتاً) عند الوصول لإزاحة معينة أثناء التمرير."
  },
  {
    id: 199,
    category: "CSS",
    question: "كيف تحدد لون الـ Outline الذي يظهر عند التركيز؟",
    options: ["border-focus", "outline-color", "focus-color", "ring-color"],
    correctAnswer: 1,
    explanation: "outline-color هي الخاصية المسؤولة عن تغيير لون الحد الخارجي (outline)."
  },
  {
    id: 200,
    category: "CSS",
    question: "أي خاصية تمنع المستخدم من تحديد النص (Selection)؟",
    options: ["user-select: none", "text-select: none", "select: disabled", "copy: none"],
    correctAnswer: 0,
    explanation: "user-select: none تمنع المستخدم من تظليل أو تحديد النص داخل العنصر."
  },
  // ==========================================
  // GIT SECTION (IDs 201-250)
  // Total: 50 Questions
  // ==========================================
  {
    id: 201,
    category: "Git",
    question: "ما هو الأمر المستخدم لتهيئة مستودع Git جديد؟",
    options: ["git init", "git start", "git new", "git create"],
    correctAnswer: 0,
    explanation: "يستخدم `git init` لإنشاء مستودع Git جديد فارغ أو إعادة تهيئة مستودع موجود."
  },
  {
    id: 202,
    category: "Git",
    question: "ما هو الأمر المستخدم لمعرفة حالة الملفات في المستودع؟",
    options: ["git info", "git status", "git check", "git state"],
    correctAnswer: 1,
    explanation: "`git status` يعرض حالة الملفات (المعدلة، المضافة، غير المتبعة) في دليل العمل."
  },
  {
    id: 203,
    category: "Git",
    question: "كيف تضيف ملفاً معيناً إلى منطقة التحضير (Staging Area)؟",
    options: ["git add <filename>", "git stage <filename>", "git push <filename>", "git commit <filename>"],
    correctAnswer: 0,
    explanation: "الأمر `git add` ينقل التعديلات من دليل العمل إلى منطقة التحضير."
  },
  {
    id: 204,
    category: "Git",
    question: "ما هو الأمر المستخدم لحفظ التغييرات في المستودع مع رسالة؟",
    options: ["git save -m 'msg'", "git commit -m 'msg'", "git push -m 'msg'", "git add -m 'msg'"],
    correctAnswer: 1,
    explanation: "`git commit -m` ينشئ نقطة حفظ (commit) جديدة بالتغييرات الموجودة في منطقة التحضير مع رسالة وصفية."
  },
  {
    id: 205,
    category: "Git",
    question: "كيف تقوم بنسخ مستودع بعيد (Remote Repository) إلى جهازك؟",
    options: ["git pull", "git copy", "git clone", "git download"],
    correctAnswer: 2,
    explanation: "`git clone` ينسخ مستودعاً موجوداً (عادةً من خادم بعيد) إلى جهازك المحلي."
  },
  {
    id: 206,
    category: "Git",
    question: "ما هو الأمر لعرض سجل الـ Commits السابق؟",
    options: ["git history", "git log", "git show", "git records"],
    correctAnswer: 1,
    explanation: "`git log` يعرض تاريخ الإيداعات (commits) في المستودع."
  },
  {
    id: 207,
    category: "Git",
    question: "كيف تنشئ فرعاً جديداً (Branch)؟",
    options: ["git branch <name>", "git new <name>", "git checkout <name>", "git make <name>"],
    correctAnswer: 0,
    explanation: "`git branch <name>` ينشئ فرعاً جديداً دون الانتقال إليه."
  },
  {
    id: 208,
    category: "Git",
    question: "كيف تنتقل إلى فرع آخر موجود؟",
    options: ["git move <branch>", "git checkout <branch>", "git go <branch>", "git select <branch>"],
    correctAnswer: 1,
    explanation: "`git checkout <branch>` (أو `git switch`) يستخدم للانتقال إلى فرع آخر."
  },
  {
    id: 209,
    category: "Git",
    question: "ما هو الأمر لدمج فرع آخر في الفرع الحالي؟",
    options: ["git join <branch>", "git combine <branch>", "git merge <branch>", "git fuse <branch>"],
    correctAnswer: 2,
    explanation: "`git merge <branch>` يدمج تاريخ الفرع المحدد في الفرع الذي تقف عليه حالياً."
  },
  {
    id: 210,
    category: "Git",
    question: "كيف ترسل التغييرات المحلية إلى المستودع البعيد؟",
    options: ["git send", "git upload", "git push", "git commit"],
    correctAnswer: 2,
    explanation: "`git push` يرفع الإيداعات المحلية إلى المستودع البعيد."
  },
  {
    id: 211,
    category: "Git",
    question: "كيف تجلب التغييرات من المستودع البعيد وتدمجها فوراً؟",
    options: ["git fetch", "git pull", "git get", "git sync"],
    correctAnswer: 1,
    explanation: "`git pull` يقوم بعمل `git fetch` ثم `git merge` لجلب ودمج التغييرات."
  },
  {
    id: 212,
    category: "Git",
    question: "ما الفرق بين git pull و git fetch؟",
    options: [
      "pull يجلب ويدمج، fetch يجلب فقط",
      "fetch يجلب ويدمج، pull يجلب فقط",
      "لا يوجد فرق",
      "pull للملفات الكبيرة، fetch للصغيرة"
    ],
    correctAnswer: 0,
    explanation: "`git fetch` يجلب التحديثات من البعيد دون دمجها، بينما `git pull` يدمجها مباشرة."
  },
  {
    id: 213,
    category: "Git",
    question: "ما هو الأمر لإظهار الاختلافات بين الملفات المعدلة وآخر commit؟",
    options: ["git diff", "git changes", "git compare", "git show"],
    correctAnswer: 0,
    explanation: "`git diff` يعرض الفروقات بين الملفات في دليل العمل ومنطقة التحضير أو آخر إيداع."
  },
  {
    id: 214,
    category: "Git",
    question: "كيف تقوم بحذف فرع محلياً؟",
    options: ["git delete <branch>", "git remove <branch>", "git branch -d <branch>", "git erase <branch>"],
    correctAnswer: 2,
    explanation: "`git branch -d` يحذف الفرع المحدد (إذا تم دمجه)، و `-D` للحذف الاجباري."
  },
  {
    id: 215,
    category: "Git",
    question: "ما هو الأمر لإلغاء التعديلات في ملف معين واستعادته لحالته السابقة؟",
    options: ["git undo <file>", "git checkout -- <file>", "git reset <file>", "git revert <file>"],
    correctAnswer: 1,
    explanation: "`git checkout -- <file>` (أو `git restore`) يعيد الملف إلى حالته في آخر commit."
  },
  {
    id: 216,
    category: "Git",
    question: "ما وظيفة الأمر git stash؟",
    options: [
      "حذف التغييرات نهائياً",
      "حفظ التغييرات مؤقتاً في ذاكرة جانبية لتنظيف دليل العمل",
      "رفع الملفات للسيرفر",
      "إنشاء نسخة احتياطية"
    ],
    correctAnswer: 1,
    explanation: "`git stash` يحفظ التعديلات الحالية غير الملتزم بها (dirty state) في كومة (stack) ويعيد دليل العمل للحالة النظيفة."
  },
  {
    id: 217,
    category: "Git",
    question: "كيف تستعيد التغييرات المحفوظة في الـ Stash؟",
    options: ["git stash pop", "git stash get", "git stash pull", "git stash back"],
    correctAnswer: 0,
    explanation: "`git stash pop` يستعيد أحدث تغييرات محفوظة في الـ stash ويحذفها من القائمة."
  },
  {
    id: 218,
    category: "Git",
    question: "ما هو الأمر لضبط اسم المستخدم الخاص بك في Git؟",
    options: [
      "git config --global user.name 'Name'",
      "git set user 'Name'",
      "git name 'Name'",
      "git init user 'Name'"
    ],
    correctAnswer: 0,
    explanation: "`git config` يستخدم لضبط الإعدادات، و `--global` يطبقها على مستوى النظام للمستخدم."
  },
  {
    id: 219,
    category: "Git",
    question: "ما هو الأمر لإنشاء وسم (Tag) جديد لإصدار؟",
    options: ["git mark v1.0", "git tag v1.0", "git label v1.0", "git version v1.0"],
    correctAnswer: 1,
    explanation: "`git tag` يستخدم لإنشاء وسوم (تستخدم عادة لتحديد إصدارات البرمجيات)."
  },
  {
    id: 220,
    category: "Git",
    question: "كيف تضيف مستودعاً بعيداً جديداً (Remote)؟",
    options: [
      "git remote add origin <url>",
      "git connect <url>",
      "git link <url>",
      "git server add <url>"
    ],
    correctAnswer: 0,
    explanation: "`git remote add` يربط مستودعك المحلي بمستودع بعيد عبر عنوان URL."
  },
  {
    id: 221,
    category: "Git",
    question: "ما هو الأمر لإلغاء الـ staging لملف (Unstage)؟",
    options: ["git reset HEAD <file>", "git unstage <file>", "git remove <file>", "git back <file>"],
    correctAnswer: 0,
    explanation: "`git reset HEAD <file>` (أو `git restore --staged`) يزيل الملف من منطقة التحضير."
  },
  {
    id: 222,
    category: "Git",
    question: "ماذا يعني HEAD في Git؟",
    options: [
      "أول ملف في المشروع",
      "مؤشر يشير إلى الفرع الحالي أو الـ Commit الحالي",
      "الخادم الرئيسي",
      "مدير المشروع"
    ],
    correctAnswer: 1,
    explanation: "HEAD هو مؤشر (Pointer) يشير دائماً إلى مكانك الحالي في التاريخ (عادةً آخر commit في الفرع الحالي)."
  },
  {
    id: 223,
    category: "Git",
    question: "ما هو الأمر `ls` في التيرمينال؟",
    options: ["قائمة الملفات (List)", "حذف (Loss)", "بحث (Locate)", "نسخ (Last Save)"],
    correctAnswer: 0,
    explanation: "`ls` هو أمر لعرض قائمة الملفات والمجلدات في الدليل الحالي."
  },
  {
    id: 224,
    category: "Git",
    question: "ما هو الأمر `cd` في التيرمينال؟",
    options: ["إنشاء دليل (Create Directory)", "تغيير الدليل (Change Directory)", "نسخ دليل (Copy Directory)", "حذف دليل (Clear Directory)"],
    correctAnswer: 1,
    explanation: "`cd` يستخدم للتنقل بين المجلدات (Change Directory)."
  },
  {
    id: 225,
    category: "Git",
    question: "كيف تنشئ مجلداً جديداً في التيرمينال؟",
    options: ["newfolder", "create", "mkdir", "md"],
    correctAnswer: 2,
    explanation: "`mkdir` (Make Directory) هو الأمر القياسي لإنشاء مجلدات جديدة."
  },
  {
    id: 226,
    category: "Git",
    question: "كيف تنشئ ملفاً فارغاً جديداً في التيرمينال؟",
    options: ["create", "touch", "make", "new"],
    correctAnswer: 1,
    explanation: "`touch` يستخدم لإنشاء ملف فارغ جديد أو تحديث الطابع الزمني لملف موجود."
  },
  {
    id: 227,
    category: "Git",
    question: "ما هو الأمر `pwd`؟",
    options: [
      "كلمة المرور (Password)",
      "طباعة دليل العمل الحالي (Print Working Directory)",
      "السابق (Previous Directory)",
      "الطاقة (Power Down)"
    ],
    correctAnswer: 1,
    explanation: "`pwd` يعرض المسار الكامل للمجلد الذي تتواجد فيه حالياً."
  },
  {
    id: 228,
    category: "Git",
    question: "كيف تحذف ملفاً في التيرمينال؟",
    options: ["delete", "remove", "rm", "del"],
    correctAnswer: 2,
    explanation: "`rm` (Remove) هو الأمر المستخدم لحذف الملفات."
  },
  {
    id: 229,
    category: "Git",
    question: "كيف تقوم بنسخ ملف في التيرمينال؟",
    options: ["copy", "cp", "c", "dup"],
    correctAnswer: 1,
    explanation: "`cp` (Copy) هو الأمر المستخدم لنسخ الملفات والمجلدات."
  },
  {
    id: 230,
    category: "Git",
    question: "كيف تقوم بنقل أو إعادة تسمية ملف في التيرمينال؟",
    options: ["move", "mv", "rn", "transfer"],
    correctAnswer: 1,
    explanation: "`mv` (Move) يستخدم لنقل الملفات وأيضاً لإعادة تسميتها."
  },
  {
    id: 231,
    category: "Git",
    question: "ما هو الأمر `cat`؟",
    options: [
      "صورة قطة",
      "عرض محتوى الملف (Concatenate)",
      "فئة (Category)",
      "قص (Cut)"
    ],
    correctAnswer: 1,
    explanation: "`cat` يستخدم لعرض محتوى الملفات النصية في التيرمينال."
  },
  {
    id: 232,
    category: "Git",
    question: "ما هو الأمر لإزالة مجلد ومحتوياته؟",
    options: ["rm -r", "rmdir", "del /s", "remove all"],
    correctAnswer: 0,
    explanation: "`rm -r` (Recursive) يحذف المجلد وجميع الملفات والمجلدات بداخله."
  },
  {
    id: 233,
    category: "Git",
    question: "ما هو ملف .gitignore؟",
    options: [
      "ملف لتجاهل أخطاء الكود",
      "ملف يحدد الملفات التي لا يجب أن يتتبعها Git",
      "ملف لحذف المستودع",
      "ملف إعدادات المستخدم"
    ],
    correctAnswer: 1,
    explanation: "يحتوي `.gitignore` على أنماط أسماء الملفات التي يجب أن يتجاهلها Git ولا يضيفها للمستودع."
  },
  {
    id: 234,
    category: "Git",
    question: "كيف تتراجع عن commit خاطئ بإنشاء commit معاكس؟",
    options: ["git undo", "git delete", "git revert <commit>", "git remove <commit>"],
    correctAnswer: 2,
    explanation: "`git revert` ينشئ commit جديد يعكس التغييرات التي تمت في commit سابق، مما يحافظ على التاريخ."
  },
  {
    id: 235,
    category: "Git",
    question: "ما الأمر لإعادة تسمية الفرع الحالي؟",
    options: ["git branch -m <new-name>", "git rename <new-name>", "git name <new-name>", "git mv <new-name>"],
    correctAnswer: 0,
    explanation: "`git branch -m` (Move/Rename) يستخدم لإعادة تسمية الفرع."
  },
  {
    id: 236,
    category: "Git",
    question: "ما هو الأمر لعرض المعلومات حول commit معين؟",
    options: ["git see", "git view", "git show", "git details"],
    correctAnswer: 2,
    explanation: "`git show` يعرض تفاصيل كائن Git (مثل commit) ومحتواه."
  },
  {
    id: 237,
    category: "Git",
    question: "كيف تعرض قائمة الفروع البعيدة؟",
    options: ["git branch -r", "git remote show", "git list remote", "git show branches"],
    correctAnswer: 0,
    explanation: "`git branch -r` يعرض الفروع الموجودة في المستودعات البعيدة (Remotes)."
  },
  {
    id: 238,
    category: "Git",
    question: "ما هو الـ Fork في GitHub؟",
    options: [
      "أداة لتناول الطعام",
      "نسخة من مستودع شخص آخر إلى حسابك الخاص",
      "فرع جديد",
      "خطأ في الكود"
    ],
    correctAnswer: 1,
    explanation: "Fork هي عملية إنشاء نسخة من مشروع شخص آخر على حسابك لتتمكن من التعديل عليه بحرية."
  },
  {
    id: 239,
    category: "Git",
    question: "ما هو الـ Pull Request (PR)؟",
    options: [
      "طلب سحب الكود لجهازك",
      "طلب لدمج تغييراتك في المستودع الأصلي",
      "طلب حذف المستودع",
      "طلب تحديث المتصفح"
    ],
    correctAnswer: 1,
    explanation: "Pull Request هي طريقة لاقتراح تغييراتك وطلب دمجها في الفرع الرئيسي للمشروع."
  },
  {
    id: 240,
    category: "Git",
    question: "كيف تحذف ملفاً من Git ولكن تبقيه في جهازك؟",
    options: ["git rm --cached <file>", "git delete <file>", "git remove <file>", "git forget <file>"],
    correctAnswer: 0,
    explanation: "`git rm --cached` يزيل الملف من منطقة التحضير (Staging) والتتبع، لكن لا يحذفه من القرص الصلب."
  },
  {
    id: 241,
    category: "Git",
    question: "ما الأمر المستخدم للبحث عن نص داخل ملفات المشروع في Git؟",
    options: ["git find", "git search", "git grep", "git look"],
    correctAnswer: 2,
    explanation: "`git grep` أداة قوية للبحث عن النصوص والأنماط داخل الملفات التي يتتبعها Git."
  },
  {
    id: 242,
    category: "Git",
    question: "ماذا يفعل الأمر git reset --hard؟",
    options: [
      "يعيد تشغيل الكمبيوتر",
      "يعيد المستودع لحالة سابقة ويحذف كل التغييرات غير المحفوظة",
      "يحذف المستودع نهائياً",
      "يصلح الأخطاء الصعبة"
    ],
    correctAnswer: 1,
    explanation: "`git reset --hard` يعيد HEAD إلى حالة معينة ويجعل دليل العمل مطابقاً لها تماماً، محواً أي تغييرات محلية."
  },
  {
    id: 243,
    category: "Git",
    question: "كيف تتحقق من إعدادات Git الحالية؟",
    options: ["git settings", "git config --list", "git show config", "git properties"],
    correctAnswer: 1,
    explanation: "`git config --list` يعرض جميع الإعدادات المكونة حالياً لـ Git."
  },
  {
    id: 244,
    category: "Git",
    question: "ما هو الأمر لإنشاء Branch والانتقال إليه في خطوة واحدة؟",
    options: ["git checkout -b <name>", "git branch -n <name>", "git switch -c <name>", "كلا الخيارين الأول والثالث"],
    correctAnswer: 3,
    explanation: "يمكن استخدام `git checkout -b` أو الأمر الأحدث `git switch -c` لإنشاء فرع والانتقال إليه فوراً."
  },
  {
    id: 245,
    category: "Git",
    question: "ماذا تعني حالة 'Conflict' عند الدمج؟",
    options: [
      "نجاح الدمج",
      "وجود تعارض في التغييرات في نفس السطر بين الفرعين",
      "انقطاع الاتصال",
      "امتلاء القرص الصلب"
    ],
    correctAnswer: 1,
    explanation: "يحدث Conflict عندما يحاول Git دمج تغييرات متناقضة في نفس الجزء من الملف ولا يستطيع حلها آلياً."
  },
  {
    id: 246,
    category: "Git",
    question: "ما هو مجلد .git؟",
    options: [
      "مجلد يحتوي على صور المشروع",
      "مجلد مخفي يحتوي على قاعدة بيانات Git وتاريخ المشروع",
      "مجلد للكود المصدري",
      "مجلد للمكتبات الخارجية"
    ],
    correctAnswer: 1,
    explanation: "مجلد `.git` هو قلب المستودع، حيث يخزن Git كل المعلومات والتاريخ والبيانات الوصفية."
  },
  {
    id: 247,
    category: "Git",
    question: "كيف تتجاهل تغيرات أذونات الملفات (File Mode)؟",
    options: ["git config core.fileMode false", "git ignore permissions", "git chmod 777", "git mode ignore"],
    correctAnswer: 0,
    explanation: "تعديل `core.fileMode` إلى false يخبر Git بتجاهل الفروقات في أذونات الملفات (مثل executable bit)."
  },
  {
    id: 248,
    category: "Git",
    question: "ما هو الأمر لإزالة مستودع بعيد؟",
    options: ["git remote remove <name>", "git remote delete <name>", "git disconnect <name>", "git unlink <name>"],
    correctAnswer: 0,
    explanation: "`git remote remove` (أو `rm`) يفك ارتباط المستودع المحلي بالبعيد."
  },
  {
    id: 249,
    category: "Git",
    question: "ماذا يفعل الأمر git blame <file>؟",
    options: [
      "يحذف الملف",
      "يظهر من قام بتعديل كل سطر في الملف ومتى",
      "يصلح الملف",
      "ينسخ الملف"
    ],
    correctAnswer: 1,
    explanation: "`git blame` يعرض اسم المؤلف ورقم الـ commit لكل سطر في الملف، مفيد لتتبع التغييرات."
  },
  {
    id: 250,
    category: "Git",
    question: "كيف تقوم بتنظيف الملفات غير المتبعة (Untracked)؟",
    options: ["git clean", "git clear", "git wipe", "git purge"],
    correctAnswer: 0,
    explanation: "`git clean` (غالباً مع `-f` للإجبار) يحذف الملفات غير المتبعة من دليل العمل."
  },
  // ==========================================
  // JAVASCRIPT SECTION (IDs 401-465)
  // Total: 65 Questions (34 Existing + 31 New)
  // ==========================================
  // 1️⃣ Language Basics (3 questions)
  {
    id: 401,
    category: "JavaScript",
    question: "ما هي الطريقة الصحيحة لكتابة تعليق سطر واحد في JavaScript؟",
    options: ["<!-- comment -->", "# comment", "// comment", "/* comment */"],
    correctAnswer: 2,
    explanation: "تعليقات سطر واحد تبدأ بـ // في JavaScript"
  },
  {
    id: 402,
    category: "JavaScript",
    question: "ما ناتج أول برنامج JavaScript؟",
    options: ["يطبع رسالة خطأ", "يفتح نافذة تنبيه", "لا يفعل شيئًا", "يطبع 'Hello World' عند استخدام console.log"],
    correctAnswer: 3,
    explanation: "JavaScript لا يفعل شيئًا بدون أوامر، console.log يطبع الرسائل"
  },
  {
    id: 403,
    category: "JavaScript",
    question: "أي جملة تمثل بنية كود صحيحة؟",
    options: ["if x > 5 {}", "if (x > 5) {}", "if x > 5 then", "if [x > 5]"],
    correctAnswer: 1,
    explanation: "الشرط يجب أن يكون داخل أقواس عادية ()"
  },

  // 2️⃣ Variables & Naming (4 questions)
  {
    id: 404,
    category: "JavaScript",
    question: "أي كلمة تستخدم لتعريف متغير قابل للتغيير؟",
    options: ["const", "let", "static", "varible"],
    correctAnswer: 1,
    explanation: "let تستخدم لتعريف متغيرات قابلة للتغيير"
  },
  {
    id: 405,
    category: "JavaScript",
    question: "ما اسم متغير صحيح حسب قواعد التسمية؟",
    options: ["1name", "user-name", "user_name", "user name"],
    correctAnswer: 2,
    explanation: "أسماء المتغيرات يجب أن تبدأ بحرف أو _ ولا تحتوي على مسافات أو شرطات"
  },
  {
    id: 406,
    category: "JavaScript",
    question: "ما قيمة المتغير غير المهيأ؟ let x;",
    options: ["0", "null", "undefined", "false"],
    correctAnswer: 2,
    explanation: "المتغيرات غير المهيأة قيمتها undefined"
  },
  {
    id: 407,
    category: "JavaScript",
    question: "أي كلمة تستخدم لتعريف ثابت؟",
    options: ["let", "var", "const", "static"],
    correctAnswer: 2,
    explanation: "const تستخدم لتعريف ثوابت لا يمكن تغييرها"
  },

  // 3️⃣ Data Types (3 questions)
  {
    id: 408,
    category: "JavaScript",
    question: "أي نوع بيانات يمثل نص؟",
    options: ["Number", "Boolean", "String", "Object"],
    correctAnswer: 2,
    explanation: "String هو نوع البيانات المستخدم للنصوص"
  },
  {
    id: 409,
    category: "JavaScript",
    question: "ما ناتج: typeof true",
    options: ["'boolean'", "'bool'", "'true'", "'object'"],
    correctAnswer: 0,
    explanation: "typeof true يرجع 'boolean'"
  },
  {
    id: 410,
    category: "JavaScript",
    question: "أي قيمة تعتبر false؟",
    options: ["'0'", "[]", "0", "'false'"],
    correctAnswer: 2,
    explanation: "الرقم 0 يعتبر false في المقارنات المنطقية"
  },

  // 4️⃣ Operators (4 questions)
  {
    id: 411,
    category: "JavaScript",
    question: "ما ناتج: 5 % 2",
    options: ["0", "1", "2", "2.5"],
    correctAnswer: 1,
    explanation: "العامل % يعيد الباقي من القسمة، 5 % 2 = 1"
  },
  {
    id: 412,
    category: "JavaScript",
    question: "أي عامل يستخدم للمقارنة الصارمة؟",
    options: ["==", "=", "!=", "==="],
    correctAnswer: 3,
    explanation: "=== يقارن القيمة والنوع معًا"
  },
  {
    id: 413,
    category: "JavaScript",
    question: "الفرق بين == و ===؟",
    options: ["لا يوجد فرق", "=== يقارن القيمة فقط", "== يقارن النوع فقط", "=== يقارن القيمة والنوع"],
    correctAnswer: 3,
    explanation: "== يقارن القيمة فقط بعد تحويل النوع، === يقارن القيمة والنوع"
  },
  {
    id: 414,
    category: "JavaScript",
    question: "ما ناتج: '5' + 2",
    options: ["7", "'7'", "'52'", "خطأ"],
    correctAnswer: 2,
    explanation: "عند إضافة نص مع رقم، يتم تحويل الرقم لنص: '5' + 2 = '52'"
  },

  // 5️⃣ Conditions (3 questions)
  {
    id: 415,
    category: "JavaScript",
    question: "أي جملة if صحيحة؟",
    options: ["if x > 10", "if (x > 10)", "if {x > 10}", "if [x > 10]"],
    correctAnswer: 1,
    explanation: "الشرط يجب أن يكون داخل أقواس عادية ()"
  },
  {
    id: 416,
    category: "JavaScript",
    question: "متى يُستخدم else؟",
    options: ["عند تحقق الشرط", "عند عدم تحقق الشرط", "دائمًا", "لا يُستخدم مع if"],
    correctAnswer: 1,
    explanation: "else تُنفذ عندما لا يتحقق الشرط في if"
  },
  {
    id: 417,
    category: "JavaScript",
    question: "أي جملة تُستخدم لاختيار عدة حالات؟",
    options: ["if", "for", "switch", "while"],
    correctAnswer: 2,
    explanation: "switch تُستخدم لاختيار من عدة حالات مختلفة"
  },

  // 6️⃣ Loops (4 questions)
  {
    id: 418,
    category: "JavaScript",
    question: "أي حلقة تُستخدم عندما نعرف عدد التكرارات؟",
    options: ["while", "do while", "for", "if"],
    correctAnswer: 2,
    explanation: "for حلقة محددة العدد، مناسبة عندما نعرف عدد التكرارات"
  },
  {
    id: 419,
    category: "JavaScript",
    question: "ما وظيفة break؟",
    options: ["إيقاف الصفحة", "تخطي دورة واحدة", "إنهاء الحلقة", "إعادة الحلقة"],
    correctAnswer: 2,
    explanation: "break تنهي الحلقة فورًا"
  },
  {
    id: 420,
    category: "JavaScript",
    question: "ما وظيفة continue؟",
    options: ["إنهاء الحلقة", "تخطي التكرار الحالي", "إعادة الكود", "إيقاف البرنامج"],
    correctAnswer: 1,
    explanation: "continue تتخطى التكرار الحالي وتنتقل للتكرار التالي"
  },
  {
    id: 421,
    category: "JavaScript",
    question: "أي حلقة تنفذ مرة واحدة على الأقل؟",
    options: ["for", "while", "do while", "foreach"],
    correctAnswer: 2,
    explanation: "do while تنفذ الكود مرة واحدة على الأقل قبل فحص الشرط"
  },

  // 7️⃣ Functions (5 questions)
  {
    id: 422,
    category: "JavaScript",
    question: "كيف نعرّف دالة؟",
    options: ["function myFunc()", "func myFunc()", "def myFunc()", "method myFunc()"],
    correctAnswer: 0,
    explanation: "function هي الكلمة المحجوزة لتعريف دالة في JavaScript"
  },
  {
    id: 423,
    category: "JavaScript",
    question: "ما اسم القيم داخل أقواس الدالة؟",
    options: ["Variables", "Arguments", "Parameters", "Returns"],
    correctAnswer: 2,
    explanation: "Parameters هي أسماء المتغيرات في تعريف الدالة"
  },
  {
    id: 424,
    category: "JavaScript",
    question: "ما وظيفة return؟",
    options: ["طباعة القيمة", "إنهاء البرنامج", "إعادة قيمة من الدالة", "استدعاء دالة أخرى"],
    correctAnswer: 2,
    explanation: "return تعيد قيمة من الدالة للكود الذي استدعاها"
  },
  {
    id: 425,
    category: "JavaScript",
    question: "ما هي Function Expression؟",
    options: ["دالة داخل if", "دالة مخزنة في متغير", "دالة بدون اسم", "دالة سهمية فقط"],
    correctAnswer: 1,
    explanation: "Function Expression هي دالة مخزنة في متغير"
  },
  {
    id: 426,
    category: "JavaScript",
    question: "ما ميزة Arrow Function؟",
    options: ["أبطأ", "أقصر وأسهل كتابة", "لا تعيد قيمة", "لا تقبل arguments"],
    correctAnswer: 1,
    explanation: "Arrow Function توفر طريقة أقصر وأسهل لكتابة الدوال"
  },

  // 8️⃣ Arrays (5 questions)
  {
    id: 427,
    category: "JavaScript",
    question: "كيف نعرّف مصفوفة؟",
    options: ["{}", "()", "[]", "<>"],
    correctAnswer: 2,
    explanation: "[] تُستخدم لتعريف مصفوفة"
  },
  {
    id: 428,
    category: "JavaScript",
    question: "كيف نصل لأول عنصر؟ arr = [10,20,30]",
    options: ["arr(0)", "arr[1]", "arr[0]", "arr.first"],
    correctAnswer: 2,
    explanation: "الفهرسة تبدأ من 0، arr[0] يعطي أول عنصر"
  },
  {
    id: 429,
    category: "JavaScript",
    question: "أي دالة تضيف عنصر في النهاية؟",
    options: ["shift()", "pop()", "push()", "unshift()"],
    correctAnswer: 2,
    explanation: "push() تضيف عنصر في نهاية المصفوفة"
  },
  {
    id: 430,
    category: "JavaScript",
    question: "ما وظيفة forEach؟",
    options: ["إنشاء مصفوفة جديدة", "التكرار على عناصر المصفوفة", "حذف العناصر", "ترتيب المصفوفة"],
    correctAnswer: 1,
    explanation: "forEach تكرر على كل عنصر في المصفوفة"
  },
  {
    id: 431,
    category: "JavaScript",
    question: "أي حلقة مناسبة للمصفوفات؟",
    options: ["for...in", "for...of", "while", "switch"],
    correctAnswer: 1,
    explanation: "for...of مناسبة للتكرار على عناصر المصفوفة"
  },

  // 9️⃣ Objects/Dictionary (2 questions)
  {
    id: 432,
    category: "JavaScript",
    question: "كيف نعرّف Object؟",
    options: ["{}", "()", "[]", "<>"],
    correctAnswer: 0,
    explanation: "{} تُستخدم لتعريف Object"
  },
  {
    id: 433,
    category: "JavaScript",
    question: "كيف نصل لقيمة داخل Object؟",
    options: ["obj(key)", "obj.key", "obj[key] فقط", "obj->key"],
    correctAnswer: 1,
    explanation: "obj.key هي الطريقة الشائعة للوصول لقيمة في Object"
  },

  // 🔟 Recap (1 question)
  {
    id: 434,
    category: "JavaScript",
    question: "JavaScript هي لغة:",
    options: ["مترجمة فقط", "تعمل في المتصفح", "خاصة بالسيرفر فقط", "لغة تصميم"],
    correctAnswer: 1,
    explanation: "JavaScript تعمل في المتصفح وتُستخدم لجعل صفحات الويب تفاعلية"
  },

  // Variables (New Questions)
  {
    id: 435,
    category: "JavaScript",
    question: "أي كود يعرّف متغيرًا صحيحًا في JavaScript؟",
    options: ["int x = 5;", "let x = 5;", "x := 5;", "var x == 5;"],
    correctAnswer: 1,
    explanation: "let x = 5; هو التعريف الصحيح للمتغير في JavaScript الحديث."
  },
  {
    id: 436,
    category: "JavaScript",
    question: "أي كود يعرّف ثابتًا لا يمكن تغييره؟",
    options: ["let PI = 3.14;", "var PI = 3.14;", "const PI = 3.14;", "static PI = 3.14;"],
    correctAnswer: 2,
    explanation: "const PI = 3.14; يعرّف ثابتًا لا يمكن إعادة تعيين قيمته."
  },

  // Conditions (New Questions)
  {
    id: 437,
    category: "JavaScript",
    question: "أي كود if صحيح؟",
    options: ["if x > 10 { console.log(x); }", "if (x > 10) console.log(x);", "if (x > 10) { console.log(x); }", "if {x > 10}"],
    correctAnswer: 2,
    explanation: "الجملة الشرطية الصحيحة هي if (x > 10) { console.log(x); }."
  },
  {
    id: 438,
    category: "JavaScript",
    question: "أي كود يستخدم strict equality؟",
    options: ["if (x == 5)", "if (x = 5)", "if (x === 5)", "if (x => 5)"],
    correctAnswer: 2,
    explanation: "=== هو عامل المساواة الصارم (strict equality) الذي يقارن القيمة والنوع."
  },

  // Loops (New Questions)
  {
    id: 439,
    category: "JavaScript",
    question: "أي كود for loop صحيح؟",
    options: ["for i = 0; i < 5; i++", "for (i < 5; i++)", "for (let i = 0; i < 5; i++) { console.log(i); }", "loop (i = 0; i < 5)"],
    correctAnswer: 2,
    explanation: "حلقة for الصحيحة هي for (let i = 0; i < 5; i++) { ... }."
  },
  {
    id: 440,
    category: "JavaScript",
    question: "أي كود يطبع الأرقام من 1 إلى 3 باستخدام while؟",
    options: ["let i = 1; while (i < 3) { console.log(i); }", "let i = 1; while (i <= 3) { console.log(i); i++; }", "while i <= 3", "do (i <= 3)"],
    correctAnswer: 1,
    explanation: "الكود الثاني يطبع الأرقام من 1 إلى 3 بشكل صحيح ويزيد قيمة العداد i."
  },

  // Functions (New Questions)
  {
    id: 441,
    category: "JavaScript",
    question: "أي كود يعرّف دالة صحيحة؟",
    options: ["function = sum(a, b)", "def sum(a, b)", "function sum(a, b) { return a + b; }", "sum(a, b) => a + b"],
    correctAnswer: 2,
    explanation: "function sum(a, b) { return a + b; } هو التعريف الصحيح للدالة."
  },
  {
    id: 442,
    category: "JavaScript",
    question: "أي كود يمثل Arrow Function صحيحة؟",
    options: ["(a, b) -> a + b", "function (a, b) => a + b", "const sum = (a, b) => a + b;", "arrow sum(a, b)"],
    correctAnswer: 2,
    explanation: "const sum = (a, b) => a + b; هو الصيغة الصحيحة لـ Arrow Function."
  },

  // Arrays (New Questions)
  {
    id: 443,
    category: "JavaScript",
    question: "أي كود يعرّف مصفوفة صحيحة؟",
    options: ["let arr = (1,2,3)", "let arr = {1,2,3}", "let arr = [1,2,3];", "let arr = <1,2,3>"],
    correctAnswer: 2,
    explanation: "يتم تعريف المصفوفات باستخدام الأقواس المربعة []."
  },
  {
    id: 444,
    category: "JavaScript",
    question: "أي كود يضيف عنصرًا إلى نهاية المصفوفة؟",
    options: ["arr.add(4);", "arr.push(4);", "arr.insert(4);", "arr.append(4);"],
    correctAnswer: 1,
    explanation: "arr.push(4); تضيف العنصر 4 إلى نهاية المصفوفة."
  },
  {
    id: 445,
    category: "JavaScript",
    question: "أي كود يكرر عناصر المصفوفة بشكل صحيح؟",
    options: ["for (item in arr) { console.log(item); }", "for (let item of arr) { console.log(item); }", "foreach arr(item)", "loop arr"],
    correctAnswer: 1,
    explanation: "for (let item of arr) هي الطريقة الصحيحة لتكرار عناصر المصفوفة."
  },

  // Objects (New Questions)
  {
    id: 446,
    category: "JavaScript",
    question: "أي كود يعرّف Object صحيح؟",
    options: ["let user = [name: \"Ali\", age: 20]", "let user = (name = \"Ali\")", "let user = { name: \"Ali\", age: 20 };", "let user = <name=\"Ali\">"],
    correctAnswer: 2,
    explanation: "يتم تعريف الكائنات (Objects) باستخدام الأقواس المعقوفة {}."
  },
  {
    id: 447,
    category: "JavaScript",
    question: "أي كود يصل إلى قيمة name؟",
    options: ["user(name)", "user->name", "user.name", "user[name]"],
    correctAnswer: 2,
    explanation: "user.name هي الطريقة الشائعة للوصول إلى خصائص الكائن."
  },

  // Output (New Questions)
  {
    id: 448,
    category: "JavaScript",
    question: "أي كود يطبع \"Hello World\" في الكونسول؟",
    options: ["print(\"Hello World\");", "echo \"Hello World\";", "console.log(\"Hello World\");", "log(\"Hello World\");"],
    correctAnswer: 2,
    explanation: "console.log() هي الدالة المستخدمة للطباعة في الكونسول."
  },

  // Recap (New Questions)
  {
    id: 449,
    category: "JavaScript",
    question: "أي كود صحيح لتعريف متغير ثم طباعته؟",
    options: ["let x == 5; console(x);", "let x = 5; console.log(x);", "var x := 5; print(x);", "x = int 5;"],
    correctAnswer: 1,
    explanation: "let x = 5; console.log(x); هو الكود الصحيح."
  },

  // English Questions (Now Translated)
  {
    id: 450,
    category: "JavaScript",
    question: "كيف تكتب \"Hello World\" في صندوق تنبيه؟",
    options: ["alertBox(\"Hello World\");", "msg(\"Hello World\");", "alert(\"Hello World\");", "console.alert(\"Hello World\");"],
    correctAnswer: 2,
    explanation: "The alert() function displays an alert box with a specified message."
  },
  {
    id: 451,
    category: "JavaScript",
    question: "كيف تنشئ دالة في JavaScript؟",
    options: ["function myFunction()", "def myFunction()", "create myFunction()", "func myFunction()"],
    correctAnswer: 0,
    explanation: "Functions are declared with the 'function' keyword followed by the name and parentheses."
  },
  {
    id: 452,
    category: "JavaScript",
    question: "كيف تستدعي دالة باسم \"myFunction\"؟",
    options: ["call myFunction()", "myFunction()", "execute myFunction()", "run myFunction()"],
    correctAnswer: 1,
    explanation: "To call a function, simply use its name followed by parentheses."
  },
  {
    id: 453,
    category: "JavaScript",
    question: "كيف تكتب جملة IF في JavaScript؟",
    options: ["if i = 5", "if (i == 5)", "if i == 5 then", "if i === 5 then"],
    correctAnswer: 1,
    explanation: "IF statements must have the condition enclosed in parentheses: if (condition)."
  },
  {
    id: 454,
    category: "JavaScript",
    question: "كيف تكتب جملة IF لتنفيذ كود إذا كانت \"i\" لا تساوي 5؟",
    options: ["if (i =! 5)", "if (i != 5)", "if (i !=== 5)", "if (i !== 5)"],
    correctAnswer: 1,
    explanation: "The != operator checks for inequality."
  },
  {
    id: 455,
    category: "JavaScript",
    question: "كيف تبدأ حلقة WHILE؟",
    options: ["while i <= 10:", "while (i <= 10)", "for (i <= 10)", "do while (i <= 10)"],
    correctAnswer: 1,
    explanation: "A while loop starts with the keyword 'while' followed by the condition in parentheses."
  },
  {
    id: 456,
    category: "JavaScript",
    question: "كيف تبدأ حلقة FOR؟",
    options: ["for (i = 0; i <= 5; i++)", "for i = 0 to 5", "for (i < 5)", "for (i = 0; i <= 5)"],
    correctAnswer: 0,
    explanation: "A standard for loop syntax is: for (initialization; condition; increment)."
  },
  {
    id: 457,
    category: "JavaScript",
    question: "كيف تضيف تعليق في JavaScript؟",
    options: ["<!-- This is a comment -->", "//This is a comment", "#This is a comment", "/* This is a comment */"],
    correctAnswer: 1,
    explanation: "// is used for single-line comments in JavaScript."
  },
  {
    id: 458,
    category: "JavaScript",
    question: "كيف تدرج تعليق يحتوي على أكثر من سطر واحد؟",
    options: ["//This comment has more than one line", "/* This comment has more than one line */", "<!-- This comment has more than one line -->", "#This comment has more than one line"],
    correctAnswer: 1,
    explanation: "/* ... */ is used for multi-line comments."
  },
  {
    id: 459,
    category: "JavaScript",
    question: "ما هي الطريقة الصحيحة لكتابة مصفوفة JavaScript؟",
    options: ["var colors = (red, green, blue)", "var colors = [\"red\", \"green\", \"blue\"]", "var colors = { \"red\", \"green\", \"blue\" }", "var colors = <\"red\", \"green\", \"blue\">"],
    correctAnswer: 1,
    explanation: "Arrays are defined using square brackets []."
  },
  {
    id: 460,
    category: "JavaScript",
    question: "كيف تقرب الرقم 7.25 إلى أقرب عدد صحيح؟",
    options: ["Math.round(7.25)", "Math.floor(7.25)", "Math.ceil(7.25)", "Math.int(7.25)"],
    correctAnswer: 0,
    explanation: "Math.round() rounds a number to the nearest integer."
  },
  {
    id: 461,
    category: "JavaScript",
    question: "كيف تجد الرقم الأعلى قيمة بين x و y؟",
    options: ["Math.high(x, y)", "Math.max(x, y)", "Math.largest(x, y)", "Math.greater(x, y)"],
    correctAnswer: 1,
    explanation: "Math.max() returns the number with the highest value."
  },
  {
    id: 462,
    category: "JavaScript",
    question: "كيف تعرّف متغير JavaScript؟",
    options: ["variable carName;", "var carName;", "let carName();", "v carName;"],
    correctAnswer: 1,
    explanation: "var, let, or const are used to declare variables. 'var carName;' is a valid declaration."
  },
  {
    id: 463,
    category: "JavaScript",
    question: "أي عامل يُستخدم لإسناد قيمة إلى متغير؟",
    options: ["==", "=", "===", "!="],
    correctAnswer: 1,
    explanation: "The = operator is used for assignment."
  },
  {
    id: 464,
    category: "JavaScript",
    question: "ما الذي ستعيده الكود التالي: Boolean(10 > 9)",
    options: ["false", "true", "0", "\"true\""],
    correctAnswer: 1,
    explanation: "10 is greater than 9, so the expression evaluates to true."
  },
  {
    id: 465,
    category: "JavaScript",
    question: "هل JavaScript حساسة لحالة الأحرف؟",
    options: ["Yes", "No", "Sometimes", "Only in variables"],
    correctAnswer: 0,
    explanation: "Yes, JavaScript is a case-sensitive language (e.g., myVar is different from MyVar)."
  },
  // Category: Conditions
  {
    id: 466,
    category: "JavaScript",
    question: "أي كود IF صحيح لطباعة \"Adult\" إذا كان العمر 18 أو أكثر؟",
    options: ["if age >= 18 { console.log(\"Adult\"); }", "if (age >= 18) { console.log(\"Adult\"); }", "if age => 18 { console.log(\"Adult\"); }", "if (age => 18) console.log(\"Adult\");"],
    correctAnswer: 1,
    explanation: "صيغة if الصحيحة تتطلب وضع الشرط بين قوسين دائريين ()."
  },
  {
    id: 467,
    category: "JavaScript",
    question: "أي كود IF-ELSE صحيح لطباعة \"Minor\" أو \"Adult\" حسب العمر؟",
    options: ["if (age < 18) { console.log(\"Minor\"); } else { console.log(\"Adult\"); }", "if age < 18 console.log(\"Minor\") else console.log(\"Adult\")", "if (age < 18) console.log(\"Minor\"); else console.log(\"Adult\")", "if (age => 18) { console.log(\"Adult\"); } else console.log(\"Minor\");"],
    correctAnswer: 0,
    explanation: "البنية الصحيحة هي if (شرط) { ... } else { ... }."
  },

  // Category: Loops
  {
    id: 468,
    category: "JavaScript",
    question: "أي كود FOR يطبع الأعداد من 1 إلى 5؟",
    options: ["for (let i = 1; i <= 5; i++) { console.log(i); }", "for (let i = 0; i < 5; i++) console.log(i);", "for i = 1 to 5 console.log(i)", "for (i = 1; i < 5; i--) console.log(i);"],
    correctAnswer: 0,
    explanation: "يجب أن يبدأ العداد من 1 ويستمر طالما i <= 5 ويزيد بمقدار 1 في كل دورة."
  },
  {
    id: 469,
    category: "JavaScript",
    question: "أي كود WHILE صحيح لطباعة الأعداد الزوجية حتى 10؟",
    options: ["let i = 2; while (i <= 10) { console.log(i); i += 2; }", "let i = 2; while i <= 10 { console.log(i); i += 2; }", "let i = 0; while (i <= 10) { console.log(i*2); }", "for (let i=2; i<=10; i+=2) console.log(i);"],
    correctAnswer: 0,
    explanation: "نبدأ بـ i=2، وطالما i أصغر أو يساوي 10 نطبع i ثم نضيف 2."
  },

  // Category: Functions & Return
  {
    id: 470,
    category: "JavaScript",
    question: "أي كود دالة صحيحة تحسب العمر المتبقي حتى 120؟ (Input: age, Output: \"xx years till 120\")",
    options: ["function yearsTill120(age) { let remaining = 120 - age; return remaining + \" years till 120\"; }", "function yearsTill120(age) { remaining = 120 - age; console.log(remaining + \" years till 120\"); }", "function yearsTill120(age) console.log(120 - age);", "let yearsTill120 = age => console.log(120-age);"],
    correctAnswer: 0,
    explanation: "الدالة الصحيحة تقوم بحساب القيمة وإعادتها باستخدام return لتنسيقها كنص."
  },
  {
    id: 471,
    category: "JavaScript",
    question: "أي كود Arrow Function يعطي نفس النتيجة؟",
    options: ["const yearsTill120 = (age) => 120 - age; console.log(yearsTill120(25) + \" years till 120\");", "const yearsTill120 = age => return 120-age;", "const yearsTill120(age) = 120 - age;", "yearsTill120 = (age) => console.log(120-age);"],
    correctAnswer: 0,
    explanation: "Arrow Function المختصرة تعيد القيمة تلقائيًا (Implicit return) ويمكن استخدامها داخل console.log."
  },

  // Category: Arrays
  {
    id: 472,
    category: "JavaScript",
    question: "أي كود يضيف عنصر جديد إلى مصفوفة أسماء المستخدمين؟ (let users = [\"Ali\", \"Sara\"];)",
    options: ["users.add(\"Omar\");", "users.push(\"Omar\");", "users.insert(\"Omar\");", "users.append(\"Omar\");"],
    correctAnswer: 1,
    explanation: "push() هي الدالة الصحيحة في JavaScript لإضافة عنصر إلى نهاية المصفوفة."
  },
  {
    id: 473,
    category: "JavaScript",
    question: "أي كود يطبع كل عناصر المصفوفة باستخدام for...of؟",
    options: ["for (let i in users) { console.log(i); }", "for (let u of users) { console.log(u); }", "users.forEach(u => console.log(users));", "for (let i = 0; i < users.length; i++); console.log(users[i]);"],
    correctAnswer: 1,
    explanation: "for...of تستخدم للمرور على قيم عناصر المصفوفة مباشرة."
  },

  // Category: Code Challenge – Recap Till 120
  {
    id: 474,
    category: "JavaScript",
    question: "أي كود صحيح لطباعة عدد السنوات المتبقية حتى 120؟ (let age = parseInt(inp);)",
    options: ["let reminingYears = 120 - age; console.log(`${reminingYears} years till 120`);", "let remaining = age - 120; console.log(`${remaining} years till 120`);", "console.log(age - 120 + \" years till 120\");", "let remaining = 120 - age; alert(remaining + \" years till 120\");"],
    correctAnswer: 0,
    explanation: "يتم حساب المتبقي بطرح العمر من 120 (120 - age) واستخدام Template Literals للطباعة."
  },
  {
    id: 475,
    category: "JavaScript",
    question: "أي كود يضمن لا طباعة أي شيء آخر؟",
    options: ["let age = parseInt(inp); let remaining = 120 - age; console.log(`${remaining} years till 120`);", "let age = parseInt(inp); console.log(\"Your age is \" + age); let remaining = 120 - age; console.log(remaining + \" years till 120\");", "console.log(120 - age + \" years till 120\"); console.log(\"Done!\");", "alert(120 - age + \" years till 120\");"],
    correctAnswer: 0,
    explanation: "الخيار الأول يقوم فقط بحساب وعرض النتيجة المطلوبة دون أي رسائل إضافية (Side effects)."
  },
  // ------------------------------------------------------------------
  //  New Questions Added (IDs 476-495)
  // ------------------------------------------------------------------

  // Conditions Category
  {
    id: 476,
    category: "JavaScript",
    question: "أي كود يتحقق إذا كانت القيمة x أكبر من 10؟",
    options: ["if x > 10 {}", "if (x > 10) {}", "if x => 10 {}", "if (x >=10:"],
    correctAnswer: 1,
    explanation: "الجملة الشرطية if تتطلب وضع الشرط بين قوسين دائريين ()."
  },
  {
    id: 477,
    category: "JavaScript",
    question: "أي كود يطبع \"Minor\" إذا كانت السن أقل من 18، و\"Adult\" إذا كانت 18 أو أكثر؟",
    options: ["if (age < 18) console.log(\"Minor\"); else console.log(\"Adult\");", "if age < 18 console.log(\"Minor\"); else console.log(\"Adult\");", "if (age < 18) console.log(\"Adult\"); else console.log(\"Minor\");", "if (age => 18) console.log(\"Adult\"); else console.log(\"Minor\");"],
    correctAnswer: 0,
    explanation: "الجملة الشرطية الصحيحة تتحقق مما إذا كان العمر أقل من 18 لطباعة Minor، وإلا تطبع Adult."
  },
  {
    id: 478,
    category: "JavaScript",
    question: "أي عامل يستخدم للمقارنة الصارمة للقيم والنوع؟",
    options: ["==", "=", "===", "!="],
    correctAnswer: 2,
    explanation: "العامل === يتحقق من تطابق القيمة والنوع معًا (Strict Equality)."
  },
  {
    id: 479,
    category: "JavaScript",
    question: "أي كود يتحقق إذا كانت القيمة x غير مساوية لـ 5؟",
    options: ["if (x =! 5)", "if (x != 5)", "if (x !=== 5)", "if (x => 5)"],
    correctAnswer: 1,
    explanation: "العامل != يستخدم للتحقق من عدم المساواة."
  },

  // Loops Category
  {
    id: 480,
    category: "JavaScript",
    question: "أي كود FOR يطبع الأعداد من 0 إلى 4؟",
    options: ["for (let i = 0; i < 5; i++) { console.log(i); }", "for i = 0 to 4 console.log(i)", "for (let i = 0; i <= 5; i--)", "for (let i = 1; i < 5; i++) console.log(i)"],
    correctAnswer: 0,
    explanation: "الحلقة تبدأ من 0 وتستمر طالما i أصغر من 5، مما يعني طباعة 0، 1، 2، 3، 4."
  },
  {
    id: 481,
    category: "JavaScript",
    question: "أي كود WHILE يطبع 1,2,3؟",
    options: ["let i = 1; while (i <= 3) { console.log(i); i++; }", "let i = 1; while i <= 3 { console.log(i); i++; }", "let i = 0; while (i <= 3) console.log(i*1);", "let i = 1; while (i < 3) console.log(i);"],
    correctAnswer: 0,
    explanation: "تبدأ الحلقة من 1 وتستمر حتى تساوي 3، مع زيادة العداد بمقدار 1 في كل دورة."
  },
  {
    id: 482,
    category: "JavaScript",
    question: "أي كود DO-WHILE يطبع 1 مرة على الأقل؟",
    options: ["let i = 5; do { console.log(i); } while (i < 5);", "while (i < 5) { console.log(i); }", "for (let i=0;i<5;i++){ console.log(i);}", "i = 5; while (i < 5) console.log(i);"],
    correctAnswer: 0,
    explanation: "حلقة do-while تضمن تنفيذ الكود مرة واحدة على الأقل حتى لو كان الشرط غير محقق في البداية."
  },
  {
    id: 483,
    category: "JavaScript",
    question: "أي كود يوقف الحلقة فورًا؟",
    options: ["continue;", "break;", "stop;", "exit;"],
    correctAnswer: 1,
    explanation: "الكلمة المحجوزة break تستخدم لإيقاف الحلقة والخروج منها فورًا."
  },
  {
    id: 484,
    category: "JavaScript",
    question: "أي كود يتجاوز الدورة الحالية للحلقة؟",
    options: ["continue;", "break;", "skip;", "pass;"],
    correctAnswer: 0,
    explanation: "الكلمة المحجوزة continue تتخطى الكود المتبقي في الدورة الحالية وتنتقل للدورة التالية."
  },

  // Arrays Category
  {
    id: 485,
    category: "JavaScript",
    question: "أي كود يعرّف مصفوفة صحيحة؟",
    options: ["let arr = [1,2,3];", "let arr = {1,2,3};", "let arr = (1,2,3);", "let arr = <1,2,3>;"],
    correctAnswer: 0,
    explanation: "تُستخدم الأقواس المربعة [] لتعريف المصفوفات في JavaScript."
  },
  {
    id: 486,
    category: "JavaScript",
    question: "أي كود يضيف عنصر في نهاية المصفوفة؟",
    options: ["arr.add(4);", "arr.push(4);", "arr.insert(4);", "arr.append(4);"],
    correctAnswer: 1,
    explanation: "دالة push() تستخدم لإضافة عنصر أو أكثر إلى نهاية المصفوفة."
  },
  {
    id: 487,
    category: "JavaScript",
    question: "أي كود يطبع كل عناصر المصفوفة؟",
    options: ["for (let x of arr) { console.log(x); }", "for (x in arr) { console.log(x); }", "arr.forEach(x => console.log(arr));", "for (let i=0;i<arr.length;i++); console.log(arr[i]);"],
    correctAnswer: 0,
    explanation: "حلقة for...of هي طريقة حديثة وواضحة للمرور على جميع عناصر المصفوفة وطباعتها."
  },
  {
    id: 488,
    category: "JavaScript",
    question: "أي كود يقطع المصفوفة من العنصر 1 إلى 3؟",
    options: ["arr.slice(1,3);", "arr.splice(1,3);", "arr.cut(1,3);", "arr.remove(1,3);"],
    correctAnswer: 0,
    explanation: "دالة slice(start, end) تعيد نسخة من جزء من المصفوفة دون تعديل الأصل."
  },

  // Functions Category
  {
    id: 489,
    category: "JavaScript",
    question: "أي كود يعرّف دالة صحيحة؟",
    options: ["function sum(a,b){ return a+b; }", "func sum(a,b){ return a+b; }", "function sum(a,b) return a+b;", "sum(a,b) => a+b;"],
    correctAnswer: 0,
    explanation: "التعريف الصحيح للدالة يبدأ بكلمة function ثم الاسم والمعاملات والجسم بين {}."
  },
  {
    id: 490,
    category: "JavaScript",
    question: "أي كود Arrow Function صحيح؟",
    options: ["const sum = (a,b) => a+b;", "const sum => (a,b) a+b;", "const sum = (a,b) return a+b;", "sum(a,b) => a+b;"],
    correctAnswer: 0,
    explanation: "Arrow Function تعرف باستخدام =>. في حالة سطر واحد، يكون الإرجاع ضمنيًا."
  },
  {
    id: 491,
    category: "JavaScript",
    question: "أي كود يستدعي الدالة؟",
    options: ["call sum(1,2);", "sum(1,2);", "execute sum(1,2);", "run sum(1,2);"],
    correctAnswer: 1,
    explanation: "يتم استدعاء الدالة بكتابة اسمها متبوعًا بالأقواس والمعاملات."
  },
  {
    id: 492,
    category: "JavaScript",
    question: "أي كود يعيد قيمة من الدالة؟",
    options: ["return a+b;", "console.log(a+b);", "print(a+b);", "output(a+b);"],
    correctAnswer: 0,
    explanation: "كلمة return تستخدم لإعادة قيمة من الدالة وإنهاء تنفيذها."
  },

  // Operators & Numbers / String / Boolean Category
  {
    id: 493,
    category: "JavaScript",
    question: "أي كود يقارن القيم فقط (loose equality)؟",
    options: ["x == y", "x === y", "x = y", "x != y"],
    correctAnswer: 0,
    explanation: "العامل == يقارن القيم فقط ويقوم بتحويل النوع إذا لزم الأمر (Loose Equality)."
  },
  {
    id: 494,
    category: "JavaScript",
    question: "أي كود يطبع TRUE إذا 10 أكبر من 5؟",
    options: ["console.log(Boolean(10>5));", "console.log(10<5);", "console.log(10!=5);", "console.log(10==5);"],
    correctAnswer: 0,
    explanation: "التعبير 10>5 يعيد true، و Boolean() يؤكد ذلك."
  },
  {
    id: 495,
    category: "JavaScript",
    question: "أي كود يقرب الرقم 7.8 إلى أقرب عدد صحيح؟",
    options: ["Math.round(7.8)", "Math.floor(7.8)", "Math.ceil(7.8)", "Math.trunc(7.8)"],
    correctAnswer: 0,
    explanation: "دالة Math.round() تقرب الرقم إلى أقرب عدد صحيح (7.8 تصبح 8)."
  }
];

export default quizData;
