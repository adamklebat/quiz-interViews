
import React, { createContext, useContext, useState, useEffect } from 'react';
import allQuizData from '@/data/QuizData';

const QuizContext = createContext();

export const useQuiz = () => {
  const context = useContext(QuizContext);
  if (!context) {
    throw new Error('useQuiz must be used within QuizProvider');
  }
  return context;
};

export const QuizProvider = ({ children }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState([]);
  const [isCompleted, setIsCompleted] = useState(false);
  const [quizType, setQuizTypeState] = useState(null); // 'html', 'css', 'git', 'javascript', 'mixed', or null
  const [activeQuizData, setActiveQuizData] = useState([]);

  // Effect to filter questions when quizType changes
  useEffect(() => {
    if (!quizType) {
      setActiveQuizData([]);
      return;
    }

    let filteredData = [];
    switch (quizType) {
      case 'html':
        filteredData = allQuizData.filter(q => q.category === 'HTML');
        break;
      case 'css':
        filteredData = allQuizData.filter(q => q.category === 'CSS');
        break;
      case 'git':
        filteredData = allQuizData.filter(q => q.category === 'Git');
        break;
      case 'javascript':
        filteredData = allQuizData.filter(q => q.category === 'JavaScript');
        break;
      case 'mixed':
      default:
        filteredData = [...allQuizData]; // Use all questions
        break;
    }
    
    // Sort logic or shuffling could be added here if needed
    setActiveQuizData(filteredData);
    setUserAnswers(Array(filteredData.length).fill(null));
    setCurrentQuestionIndex(0);
    setIsCompleted(false);
  }, [quizType]);

  const setQuizType = (type) => {
    setQuizTypeState(type);
  };

  const resetQuizType = () => {
    setQuizTypeState(null);
    setActiveQuizData([]);
    setCurrentQuestionIndex(0);
    setIsCompleted(false);
    setUserAnswers([]);
  };

  // Derived state for the current question
  const selectedAnswer = userAnswers[currentQuestionIndex];
  const isAnswered = selectedAnswer !== null && selectedAnswer !== undefined;
  
  // For this immediate feedback mode, we show the correct answer as soon as the user answers
  const showCorrectAnswer = isAnswered;

  const checkAnswer = (answerIndex) => {
    // Prevent changing answer if already answered
    if (isAnswered) return false;

    const newAnswers = [...userAnswers];
    newAnswers[currentQuestionIndex] = answerIndex;
    setUserAnswers(newAnswers);

    const isCorrect = answerIndex === activeQuizData[currentQuestionIndex].correctAnswer;
    return isCorrect;
  };

  // Legacy support for older components
  const selectAnswer = checkAnswer;

  const nextQuestion = () => {
    if (currentQuestionIndex < activeQuizData.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const previousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const setCurrentQuestion = (index) => {
    if (index >= 0 && index < activeQuizData.length) {
      setCurrentQuestionIndex(index);
    }
  };

  const finishQuiz = () => {
    setIsCompleted(true);
  };

  const resetQuiz = () => {
    setCurrentQuestionIndex(0);
    setUserAnswers(Array(activeQuizData.length).fill(null));
    setIsCompleted(false);
  };

  const calculateScore = () => {
    let correct = 0;
    userAnswers.forEach((answer, index) => {
      if (activeQuizData[index] && answer === activeQuizData[index].correctAnswer) {
        correct++;
      }
    });
    return correct;
  };

  const getPerformanceMessage = (score) => {
    if (activeQuizData.length === 0) return '';
    
    const percentage = (score / activeQuizData.length) * 100;
    if (percentage >= 90) return 'ممتاز! 🌟';
    if (percentage >= 80) return 'جيد جداً! 👏';
    if (percentage >= 70) return 'جيد! 👍';
    if (percentage >= 60) return 'مقبول 📚';
    return 'يحتاج إلى مزيد من المراجعة 📖';
  };

  const value = {
    currentQuestionIndex,
    userAnswers,
    isCompleted,
    quizData: activeQuizData, // Expose filtered data as standard quizData
    selectedAnswer,
    isAnswered,
    showCorrectAnswer,
    checkAnswer,
    selectAnswer,
    nextQuestion,
    previousQuestion,
    setCurrentQuestion,
    finishQuiz,
    resetQuiz,
    calculateScore,
    getPerformanceMessage,
    quizType,
    setQuizType,
    resetQuizType
  };

  return <QuizContext.Provider value={value}>{children}</QuizContext.Provider>;
};
