
import React from 'react';
import QuizApp from '@/components/QuizApp';

function App() {
  return <QuizApp />;
}

export default App;
