import React from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Code2, ArrowLeft } from 'lucide-react';
import { QuizProvider, useQuiz } from '@/context/QuizContext';
import QuestionCard from '@/components/QuestionCard';
import QuizNavigation from '@/components/QuizNavigation';
import ResultsPage from '@/components/ResultsPage';
import QuizSelector from '@/components/QuizSelector';
import { Toaster } from '@/components/ui/toaster';
import { Button } from '@/components/ui/button';

const QuizContent = () => {
  const { isCompleted, quizType, resetQuizType } = useQuiz();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-slate-900 py-8 md:py-12 px-4 relative overflow-x-hidden w-full">
      <Helmet>
        <title>منصة اختبارات تطوير الويب - HTML, CSS & Git</title>
        <meta name="description" content="اختبر معرفتك في تطوير الويب مع مجموعة شاملة من أسئلة HTML و CSS و Git. اختبارات تفاعلية للمبتدئين والمحترفين." />
      </Helmet>

      {/* Header - Always visible but changes based on state */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8 md:mb-12 relative z-10 w-full max-w-full px-2"
      >
        <div className="max-w-4xl mx-auto flex flex-col items-center">
          <div className="flex items-center justify-center gap-2 md:gap-3 mb-4 flex-wrap">
            <Code2 className="w-10 h-10 md:w-12 md:h-12 text-purple-400" />
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 text-center">
              منصة اختبارات الويب
            </h1>
          </div>
          
          {quizType && (
             <motion.div 
               initial={{ opacity: 0 }} 
               animate={{ opacity: 1 }}
               className="flex flex-wrap justify-center items-center gap-2 mt-2 md:mt-4"
             >
                <span className="bg-white/10 px-3 py-1 md:px-4 rounded-full text-white/90 text-xs md:text-sm border border-white/20 capitalize whitespace-nowrap">
                  {quizType === 'mixed' ? 'Mixed Quiz' : `${quizType.toUpperCase()} Quiz`}
                </span>
                {!isCompleted && (
                   <Button 
                     variant="ghost" 
                     size="sm" 
                     onClick={resetQuizType}
                     className="text-white/60 hover:text-white hover:bg-white/10 h-8 text-xs md:text-sm"
                   >
                     <ArrowLeft className="w-3 h-3 md:w-4 md:h-4 mr-1" /> تغيير الاختبار
                   </Button>
                )}
             </motion.div>
          )}
        </div>
      </motion.header>

      {/* Main Content Area */}
      <div className="w-full max-w-7xl mx-auto relative z-10">
        <AnimatePresence mode="wait">
          {!quizType ? (
            <motion.div
              key="selector"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ duration: 0.3 }}
              className="w-full"
            >
              <QuizSelector />
            </motion.div>
          ) : isCompleted ? (
            <motion.div
              key="results"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto w-full"
            >
              <ResultsPage />
            </motion.div>
          ) : (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto w-full"
            >
              <QuestionCard />
              <QuizNavigation />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <Toaster />
    </div>
  );
};

const QuizApp = () => {
  return (
    <QuizProvider>
      <QuizContent />
    </QuizProvider>
  );
};

export default QuizApp;