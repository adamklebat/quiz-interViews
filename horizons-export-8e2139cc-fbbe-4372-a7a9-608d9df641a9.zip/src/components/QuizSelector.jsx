
import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Palette, Layers, GitBranch } from 'lucide-react';
import { useQuiz } from '@/context/QuizContext';

const SelectorCard = ({ title, count, icon: Icon, onClick, description, gradient, isJs }) => (
  <motion.div
    whileHover={{ scale: 1.02, y: -5 }}
    whileTap={{ scale: 0.98 }}
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    onClick={onClick}
    className={`cursor-pointer relative overflow-hidden rounded-xl sm:rounded-2xl p-6 sm:p-8 h-full bg-gradient-to-br ${gradient} shadow-xl sm:shadow-2xl border border-white/20 w-full group`}
  >
    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity duration-300">
      {isJs ? (
        <div className="text-[8rem] font-bold text-black leading-none select-none opacity-50">JS</div>
      ) : (
        <Icon className="w-24 h-24 sm:w-32 sm:h-32" />
      )}
    </div>
    
    <div className="relative z-10 flex flex-col h-full justify-between gap-4">
      <div>
        <div className="bg-white/20 w-12 h-12 sm:w-16 sm:h-16 rounded-xl sm:rounded-2xl flex items-center justify-center mb-4 sm:mb-6 backdrop-blur-sm shadow-inner">
          {isJs ? (
             <div className="text-xl sm:text-2xl font-black text-black">JS</div>
          ) : (
            <Icon className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
          )}
        </div>
        
        <h3 className="text-2xl sm:text-3xl font-bold text-white mb-2">{title}</h3>
        <p className="text-white/80 mb-2 text-sm sm:text-base leading-relaxed">{description}</p>
      </div>
      
      <div className="flex items-center gap-2 text-white/90 font-medium bg-black/10 w-fit px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg backdrop-blur-sm text-sm sm:text-base mt-auto">
        <span>{count} سؤال</span>
      </div>
    </div>
  </motion.div>
);

const QuizSelector = () => {
  const { setQuizType } = useQuiz();

  return (
    <div className="w-full max-w-7xl mx-auto px-2 sm:px-4">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-10 sm:mb-16"
      >
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4 sm:mb-6 leading-tight">
          اختر نوع الاختبار
        </h2>
        <p className="text-lg sm:text-xl text-purple-200 max-w-2xl mx-auto px-4">
          اختبر معلوماتك في مجالات تطوير الويب المختلفة. اختر التحدي الذي يناسبك وابدأ رحلة التعلم.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 w-full">
        <SelectorCard
          title="HTML"
          count={80}
          icon={Code2}
          description="اختبر أساسيات هيكلة صفحات الويب والعناصر الدلالية"
          gradient="from-orange-500 to-red-600"
          onClick={() => setQuizType('html')}
        />
        
        <SelectorCard
          title="CSS"
          count={100}
          icon={Palette}
          description="تحدى نفسك في التنسيق، التصميم، والرسوم المتحركة"
          gradient="from-blue-500 to-indigo-600"
          onClick={() => setQuizType('css')}
        />

        <SelectorCard
          title="JavaScript"
          count={34}
          icon={Code2} 
          isJs={true}
          description="تعلم أساسيات JavaScript"
          gradient="from-yellow-400 to-orange-500"
          onClick={() => setQuizType('javascript')}
        />

        <SelectorCard
          title="Git & Terminal"
          count={50}
          icon={GitBranch}
          description="اختبر معرفتك في إدارة النسخ وسطر الأوامر"
          gradient="from-slate-600 to-slate-800"
          onClick={() => setQuizType('git')}
        />
        
        <SelectorCard
          title="شامل (Mixed)"
          count={250}
          icon={Layers}
          description="اختبار شامل يجمع HTML و CSS و Git للمحترفين"
          gradient="from-purple-500 to-pink-600"
          onClick={() => setQuizType('mixed')}
        />
      </div>
    </div>
  );
};

export default QuizSelector;
