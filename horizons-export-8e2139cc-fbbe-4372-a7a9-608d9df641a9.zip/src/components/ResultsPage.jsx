
import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, RotateCcw, LayoutGrid, CheckCircle, XCircle } from 'lucide-react';
import { useQuiz } from '@/context/QuizContext';
import { Button } from '@/components/ui/button';

const ResultsPage = () => {
  const { calculateScore, getPerformanceMessage, resetQuiz, resetQuizType, quizData, userAnswers } = useQuiz();
  
  const score = calculateScore();
  const percentage = quizData.length > 0 ? ((score / quizData.length) * 100).toFixed(2) : 0;
  const performanceMessage = getPerformanceMessage(score);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-4xl mx-auto px-2 sm:px-4"
      dir="rtl"
    >
      {/* Score Card */}
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 sm:p-8 shadow-2xl border border-white/20 mb-6 sm:mb-8 w-full">
        <div className="text-center mb-6 sm:mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring' }}
            className="inline-flex items-center justify-center w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full mb-4 sm:mb-6 shadow-lg shadow-purple-500/30"
          >
            <Trophy className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
          </motion.div>
          
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-2 sm:mb-4">
            نتيجتك النهائية
          </h2>
          
          <div className="text-4xl sm:text-5xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 mb-2 sm:mb-4">
            {score} / {quizData.length}
          </div>
          
          <div className="text-2xl sm:text-3xl font-bold text-purple-300 mb-4">
            {percentage}%
          </div>
          
          <p className="text-lg sm:text-xl md:text-2xl text-white font-semibold leading-relaxed px-2">
            {performanceMessage}
          </p>
        </div>

        <div className="flex flex-col sm:flex-row justify-center gap-3 sm:gap-4 w-full">
          <Button
            onClick={resetQuiz}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 sm:px-8 py-5 sm:py-6 text-base sm:text-lg rounded-xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg shadow-purple-500/50"
          >
            <RotateCcw className="w-5 h-5" />
            إعادة الاختبار
          </Button>
          
          <Button
            onClick={resetQuizType}
            variant="outline"
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 sm:px-8 py-5 sm:py-6 text-base sm:text-lg rounded-xl font-bold bg-white/10 hover:bg-white/20 text-white border-white/30 backdrop-blur-sm"
          >
            <LayoutGrid className="w-5 h-5" />
            اختيار اختبار آخر
          </Button>
        </div>
      </div>

      {/* Detailed Results */}
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 sm:p-6 md:p-8 shadow-2xl border border-white/20 w-full">
        <h3 className="text-xl sm:text-2xl font-bold text-white mb-4 sm:mb-6 text-center">
          مراجعة الإجابات
        </h3>
        
        <div className="space-y-3 sm:space-y-4 max-h-[500px] overflow-y-auto pr-1 sm:pr-2 custom-scrollbar">
          {quizData.map((question, index) => {
            const userAnswer = userAnswers[index];
            const isCorrect = userAnswer === question.correctAnswer;
            
            return (
              <motion.div
                key={question.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`p-3 sm:p-4 rounded-xl border-2 ${
                  isCorrect
                    ? 'bg-green-500/10 border-green-500/50'
                    : 'bg-red-500/10 border-red-500/50'
                }`}
              >
                <div className="flex items-start gap-2 sm:gap-3">
                  <div className="flex-shrink-0 mt-1">
                    {isCorrect ? (
                      <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-green-400" />
                    ) : (
                      <XCircle className="w-5 h-5 sm:w-6 sm:h-6 text-red-400" />
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-white font-bold mb-2 text-sm sm:text-base break-words">
                      {index + 1}. {question.question}
                    </p>
                    
                    <div className="space-y-2 text-xs sm:text-sm">
                      <p className="text-purple-300 break-words">
                        <span className="font-semibold ml-2">إجابتك:</span>
                        <span className={isCorrect ? 'text-green-300' : 'text-red-300'}>
                          {question.options[userAnswer] || 'لم يتم الرد'}
                        </span>
                      </p>
                      
                      {!isCorrect && (
                        <p className="text-green-300 break-words">
                          <span className="font-semibold ml-2">الإجابة الصحيحة:</span>
                          {question.options[question.correctAnswer]}
                        </p>
                      )}

                      {question.explanation && (
                         <div className="mt-2 p-3 bg-white/5 rounded-lg border border-white/10">
                            <p className="text-gray-300 text-xs sm:text-sm break-words">
                              <span className="font-bold text-purple-300 block mb-1">الشرح:</span>
                              {question.explanation}
                            </p>
                         </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
};

export default ResultsPage;
