
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, Info } from 'lucide-react';
import { useQuiz } from '@/context/QuizContext';

const AnswerOptions = () => {
  const { currentQuestionIndex, quizData, isAnswered, selectedAnswer, checkAnswer } = useQuiz();
  const currentQuestion = quizData[currentQuestionIndex];

  const handleSelectAnswer = (index) => {
    if (!isAnswered) {
      checkAnswer(index);
    }
  };

  return (
    <div className="space-y-3 md:space-y-4 w-full" dir="rtl">
      <div className="space-y-2 md:space-y-3 w-full">
        {currentQuestion.options.map((option, index) => {
          const isSelected = selectedAnswer === index;
          const isCorrect = index === currentQuestion.correctAnswer;
          
          // Determine styling based on answer state
          let buttonStyle = 'bg-white/5 text-white border-white/10 hover:bg-white/10 hover:border-purple-400/50';
          let icon = null;
          let feedbackText = null;

          if (isAnswered) {
            if (isCorrect) {
              // Correct answer styling (always green if answered)
              buttonStyle = 'bg-green-500/20 text-white border-green-500 shadow-lg shadow-green-500/20';
              icon = <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-green-400 flex-shrink-0" />;
              if (isSelected) feedbackText = <span className="text-green-400 font-bold mr-2 text-sm sm:text-base whitespace-nowrap">صحيح!</span>;
            } else if (isSelected) {
              // Wrong selected answer styling
              buttonStyle = 'bg-red-500/20 text-white border-red-500 shadow-lg shadow-red-500/20';
              icon = <XCircle className="w-5 h-5 sm:w-6 sm:h-6 text-red-400 flex-shrink-0" />;
              feedbackText = <span className="text-red-400 font-bold mr-2 text-sm sm:text-base whitespace-nowrap">خاطئ!</span>;
            } else {
              // Other non-selected wrong answers
              buttonStyle = 'bg-white/5 text-gray-400 border-transparent opacity-50';
            }
          } else if (isSelected) {
             // Selected state before validation
             buttonStyle = 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/50 border-purple-300';
          }

          return (
            <motion.button
              key={index}
              onClick={() => handleSelectAnswer(index)}
              disabled={isAnswered}
              whileHover={!isAnswered ? { scale: 1.01 } : {}}
              whileTap={!isAnswered ? { scale: 0.98 } : {}}
              className={`w-full p-3 sm:p-4 rounded-xl text-right transition-all duration-300 border-2 relative overflow-hidden ${buttonStyle} ${isAnswered ? 'cursor-default' : 'cursor-pointer'}`}
            >
              <div className="flex items-center justify-between relative z-10 w-full gap-2">
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <span className="text-base sm:text-lg font-medium break-words leading-snug">{option}</span>
                </div>
                
                <div className="flex items-center gap-2 flex-shrink-0">
                  <AnimatePresence>
                    {isAnswered && (isSelected || isCorrect) && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="flex items-center gap-1 sm:gap-2"
                      >
                        {feedbackText}
                        {icon}
                      </motion.div>
                    )}
                  </AnimatePresence>
                  
                  {/* Default selection circle if not answered yet */}
                  {!isAnswered && (
                    <div className={`w-5 h-5 sm:w-6 sm:h-6 rounded-full border-2 flex items-center justify-center transition-colors flex-shrink-0 ${
                      isSelected ? 'border-white bg-white' : 'border-white/30'
                    }`}>
                      {isSelected && (
                        <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-purple-600" />
                      )}
                    </div>
                  )}
                </div>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Explanation Section */}
      <AnimatePresence>
        {isAnswered && currentQuestion.explanation && (
          <motion.div
            initial={{ opacity: 0, y: 10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: 10, height: 0 }}
            className="overflow-hidden"
          >
            <div className={`mt-4 sm:mt-6 p-4 sm:p-5 rounded-xl border-r-4 shadow-inner ${
              selectedAnswer === currentQuestion.correctAnswer 
                ? 'bg-green-500/10 border-green-500' 
                : 'bg-blue-500/10 border-blue-400'
            }`}>
              <div className="flex items-start gap-3">
                <Info className={`w-5 h-5 sm:w-6 sm:h-6 mt-1 flex-shrink-0 ${
                  selectedAnswer === currentQuestion.correctAnswer ? 'text-green-400' : 'text-blue-400'
                }`} />
                <div className="space-y-1 w-full min-w-0">
                  <h4 className={`font-bold text-base sm:text-lg ${
                    selectedAnswer === currentQuestion.correctAnswer ? 'text-green-300' : 'text-blue-300'
                  }`}>
                    شرح الإجابة:
                  </h4>
                  <p className="text-white/90 leading-relaxed text-sm sm:text-md break-words">
                    {currentQuestion.explanation}
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AnswerOptions;
