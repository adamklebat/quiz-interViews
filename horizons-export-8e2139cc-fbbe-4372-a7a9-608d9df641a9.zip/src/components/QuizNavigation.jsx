
import React from 'react';
import { ChevronRight, ChevronLeft, CheckCircle, Lock } from 'lucide-react';
import { useQuiz } from '@/context/QuizContext';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const QuizNavigation = () => {
  const {
    currentQuestionIndex,
    quizData,
    userAnswers,
    isAnswered,
    nextQuestion,
    previousQuestion,
    setCurrentQuestion,
    finishQuiz
  } = useQuiz();

  const isFirstQuestion = currentQuestionIndex === 0;
  const isLastQuestion = currentQuestionIndex === quizData.length - 1;
  const allAnswered = userAnswers.every(answer => answer !== null);
  const answeredCount = userAnswers.filter(a => a !== null).length;

  return (
    <div className="flex flex-col gap-4 sm:gap-6 mt-6 sm:mt-8 w-full max-w-4xl mx-auto" dir="rtl">
      
      {/* Top Controls: Next/Prev Buttons and Status Text */}
      <div className="flex items-center justify-between gap-2 sm:gap-4 w-full">
        <Button
          onClick={previousQuestion}
          disabled={isFirstQuestion}
          className={`flex items-center justify-center gap-1 sm:gap-2 px-3 sm:px-6 py-2 sm:py-3 h-10 sm:h-11 rounded-lg sm:rounded-xl font-bold transition-all text-xs sm:text-sm md:text-base min-w-[80px] sm:min-w-[100px] ${
            isFirstQuestion
              ? 'bg-gray-600/50 cursor-not-allowed opacity-50'
              : 'bg-white/10 hover:bg-white/20 text-white'
          }`}
        >
          <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="hidden xs:inline">السابق</span>
        </Button>

        <div className="text-center flex-1 min-w-0 px-1">
          <p className="text-sm sm:text-lg md:text-xl font-bold text-white mb-0.5 sm:mb-1 truncate">
            السؤال {currentQuestionIndex + 1} من {quizData.length}
          </p>
          <p className="text-xs sm:text-sm text-purple-300 truncate">
            ({answeredCount} تمت الإجابة)
          </p>
        </div>

        {isLastQuestion ? (
          <Button
            onClick={finishQuiz}
            disabled={!allAnswered}
            className={`flex items-center justify-center gap-1 sm:gap-2 px-3 sm:px-6 py-2 sm:py-3 h-10 sm:h-11 rounded-lg sm:rounded-xl font-bold transition-all text-xs sm:text-sm md:text-base min-w-[80px] sm:min-w-[120px] ${
              allAnswered
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-lg shadow-green-500/50'
                : 'bg-gray-600/50 cursor-not-allowed opacity-50'
            }`}
          >
            <CheckCircle className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="hidden xs:inline">إنهاء</span>
          </Button>
        ) : (
          <Button
            onClick={nextQuestion}
            disabled={!isAnswered}
            className={`flex items-center justify-center gap-1 sm:gap-2 px-3 sm:px-6 py-2 sm:py-3 h-10 sm:h-11 rounded-lg sm:rounded-xl font-bold transition-all text-xs sm:text-sm md:text-base min-w-[80px] sm:min-w-[100px] ${
              isAnswered
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg shadow-purple-500/50'
                : 'bg-gray-600/50 cursor-not-allowed opacity-70'
            }`}
          >
            {!isAnswered && <Lock className="w-3 h-3 sm:w-4 sm:h-4 ml-1" />}
            <span className="hidden xs:inline">التالي</span>
            <ChevronLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          </Button>
        )}
      </div>

      {/* Questions Grid */}
      <div className="bg-white/5 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 border border-white/10 w-full overflow-hidden">
        <div className="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12 gap-2 max-h-48 sm:max-h-60 overflow-y-auto custom-scrollbar pr-1 sm:pr-2 w-full">
          {quizData.map((_, index) => {
            const isCurrent = currentQuestionIndex === index;
            const isAnsweredState = userAnswers[index] !== null;
            
            return (
              <motion.button
                key={index}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setCurrentQuestion(index)}
                className={cn(
                  "h-8 w-8 sm:h-10 sm:w-10 rounded-md sm:rounded-lg text-xs sm:text-sm font-bold flex items-center justify-center transition-all duration-200 shadow-sm border mx-auto",
                  isCurrent 
                    ? "bg-blue-600 border-blue-400 text-white shadow-blue-500/50 ring-2 ring-blue-400/50 z-10 scale-105 sm:scale-110" 
                    : isAnsweredState 
                      ? "bg-green-100 border-green-200 text-green-700 hover:bg-green-200" 
                      : "bg-white border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-gray-900"
                )}
              >
                {index + 1}
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default QuizNavigation;
