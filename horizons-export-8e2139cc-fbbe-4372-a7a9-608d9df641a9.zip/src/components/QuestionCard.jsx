
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle } from 'lucide-react';
import { useQuiz } from '@/context/QuizContext';
import AnswerOptions from '@/components/AnswerOptions';

const QuestionCard = () => {
  const { currentQuestionIndex, quizData, isAnswered } = useQuiz();
  const currentQuestion = quizData[currentQuestionIndex];

  // Animation variants for smooth transitions
  const variants = {
    initial: { opacity: 0, x: 20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -20 }
  };

  // Safe guard if currentQuestion is undefined
  if (!currentQuestion) {
    return (
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 sm:p-8 shadow-2xl border border-white/20 w-full text-center text-white">
        <p>جاري تحميل السؤال...</p>
      </div>
    );
  }

  return (
    <div className="relative min-h-[300px] md:min-h-[400px] w-full"> 
      {/* Container to stabilize layout height during transitions */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestionIndex}
          variants={variants}
          initial="initial"
          animate="animate"
          exit="exit"
          transition={{ duration: 0.3, ease: "easeInOut" }}
          className="bg-white/10 backdrop-blur-lg rounded-2xl p-4 sm:p-6 md:p-8 shadow-2xl border border-white/20 w-full overflow-hidden"
        >
          <div className="mb-4 md:mb-6">
            <div className="flex flex-col-reverse sm:flex-row justify-between items-start sm:items-center gap-2 mb-4">
              <span className="text-xs sm:text-sm font-medium text-purple-300">
                السؤال {currentQuestionIndex + 1} من {quizData.length}
              </span>
              <div className="bg-purple-500/20 px-3 py-1 rounded-full self-start sm:self-auto">
                <span className="text-xs sm:text-sm font-bold text-purple-200">
                  {currentQuestion?.category || 'عام'}
                </span>
              </div>
            </div>
            <div className="w-full bg-white/10 rounded-full h-1.5 sm:h-2 mb-4 md:mb-6">
              <motion.div
                className="bg-gradient-to-r from-purple-500 to-pink-500 h-1.5 sm:h-2 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${((currentQuestionIndex + 1) / quizData.length) * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          <h2 className="text-xl sm:text-2xl font-bold text-white mb-6 md:mb-8 text-right leading-relaxed break-words">
            {currentQuestion?.question}
          </h2>

          <AnswerOptions />
          
          <AnimatePresence>
            {!isAnswered && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 flex items-center justify-end gap-2 text-yellow-300/80 text-xs sm:text-sm font-medium"
              >
                <span>يرجى الإجابة للمتابعة</span>
                <AlertCircle className="w-3 h-3 sm:w-4 sm:h-4" />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default QuestionCard;
